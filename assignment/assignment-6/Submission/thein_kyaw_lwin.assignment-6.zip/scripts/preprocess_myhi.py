#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
preprocess_myhi.py
==================
Preprocesses Myanmar-Hieroglyphs parallel corpus for Marian NMT training.

Transformations:
  - Myanmar (.my): Segmented into space-separated syllables using sylbreak regex.
                   Drops test-set Out-of-Vocabulary (OOV) from 47.3% down to 2.30%.
  - Hieroglyphs (.hi): Whitespace normalized (single-space between glyph tokens).
  - Generates parallel dataset folder 'myhi-par/' ready for Kaggle dataset upload.
"""

import os
import re
import sys
import json
import shutil
from pathlib import Path

# ---------------------------------------------------------------------------
# Syllable Segmentation Engine (sylbreak regex by Dr. Ye Kyaw Thu)
# ---------------------------------------------------------------------------

MY_CONSONANT = r"က-အ"
EN_CHAR = r"a-zA-Z0-9"
SS_SYMBOL = "္"
ATHAT = "်"
OTHER_CHAR = r"ဣဤဥဦဧဩဪဿ၌၍၎၏၀-၉႐-႙၊။!-/:-@[-`’“”{-~\s…"

SYLBREAK_PATTERN = re.compile(
    rf"((?<!{SS_SYMBOL})[{MY_CONSONANT}](?![{ATHAT}{SS_SYMBOL}])|[{EN_CHAR}{OTHER_CHAR}])"
)


def break_syllables(text: str) -> str:
    """Segment Myanmar text into space-separated syllables."""
    text_clean = re.sub(r"\s+", "", str(text))
    segmented = SYLBREAK_PATTERN.sub(lambda m: " " + m.group(1), text_clean)
    return re.sub(r"^\s+|\s+$", "", segmented)


def clean_hi_line(text: str) -> str:
    """Normalize whitespace in Hieroglyphic text."""
    tokens = text.strip().split()
    return " ".join(tokens)


# ---------------------------------------------------------------------------
# Main Preprocessing Routine
# ---------------------------------------------------------------------------

def main():
    base_dir = Path(__file__).resolve().parent.parent
    raw_dir = base_dir / "myhi_data"
    out_dir = base_dir / "myhi-par"

    print(f"Base Directory : {base_dir}")
    print(f"Raw Data Dir   : {raw_dir}")
    print(f"Output Data Dir: {out_dir}")

    if not raw_dir.exists():
        print(f"[ERROR] Raw data directory not found: {raw_dir}", file=sys.stderr)
        sys.exit(1)

    out_dir.mkdir(parents=True, exist_ok=True)

    splits = [
        ("train", "train"),
        ("valid", "dev"),      # create dev.my/dev.hi standard in Marian
        ("valid", "valid"),    # also keep valid.my/valid.hi for compatibility
        ("test", "test"),
    ]

    processed_counts = {}

    for src_split, dst_name in splits:
        src_my_path = raw_dir / f"{src_split}.my"
        src_hi_path = raw_dir / f"{src_split}.hi"
        dst_my_path = out_dir / f"{dst_name}.my"
        dst_hi_path = out_dir / f"{dst_name}.hi"

        print(f"\nProcessing split: {src_split} -> {dst_name} ...")

        with open(src_my_path, "r", encoding="utf-8") as f_my, \
             open(src_hi_path, "r", encoding="utf-8") as f_hi:
            my_lines = [l.strip() for l in f_my]
            hi_lines = [l.strip() for l in f_hi]

        if len(my_lines) != len(hi_lines):
            raise ValueError(f"Line count mismatch in {src_split}: {len(my_lines)} .my vs {len(hi_lines)} .hi")

        syl_my_lines = [break_syllables(l) for l in my_lines]
        clean_hi_lines = [clean_hi_line(l) for l in hi_lines]

        with open(dst_my_path, "w", encoding="utf-8") as f_out:
            for l in syl_my_lines:
                f_out.write(l + "\n")

        with open(dst_hi_path, "w", encoding="utf-8") as f_out:
            for l in clean_hi_lines:
                f_out.write(l + "\n")

        processed_counts[dst_name] = len(syl_my_lines)
        print(f"  [OK] Wrote {len(syl_my_lines)} lines to {dst_name}.my and {dst_name}.hi")

    # Also save raw test.my for post-processing detokenization & reference comparison
    shutil.copy2(raw_dir / "test.my", out_dir / "test.my.raw")
    print(f"  [OK] Copied raw test.my to {out_dir / 'test.my.raw'}")

    # Generate Kaggle dataset-metadata.json
    metadata = {
        "title": "myhi-par",
        "id": "theinkyawlwin/myhi-par",
        "licenses": [{"name": "CC0-1.0"}],
        "keywords": ["nlp", "neural-machine-translation", "myanmar", "hieroglyphics", "marian-nmt"]
    }
    with open(out_dir / "dataset-metadata.json", "w", encoding="utf-8") as f_meta:
        json.dump(metadata, f_meta, indent=2)
    print(f"  [OK] Generated {out_dir / 'dataset-metadata.json'}")

    # Summary Statistics & Vocabulary Verification
    print("\n" + "=" * 70)
    print("Preprocessed Parallel Corpus Statistics")
    print("=" * 70)
    for split_name, count in processed_counts.items():
        print(f"  {split_name:<10}: {count:>6} pairs")

    with open(out_dir / "train.my", "r", encoding="utf-8") as f:
        train_my_tokens = [tok for line in f for tok in line.strip().split()]
    with open(out_dir / "test.my", "r", encoding="utf-8") as f:
        test_my_tokens = [tok for line in f for tok in line.strip().split()]

    train_my_vocab = set(train_my_tokens)
    test_my_vocab = set(test_my_tokens)
    my_oov = test_my_vocab - train_my_vocab

    print(f"\nMyanmar Syllable Vocab:")
    print(f"  Train unique syllables : {len(train_my_vocab):,}")
    print(f"  Test unique syllables  : {len(test_my_vocab):,}")
    print(f"  Test OOV syllables     : {len(my_oov)} ({len(my_oov)/len(test_my_vocab):.2%})")

    with open(out_dir / "train.hi", "r", encoding="utf-8") as f:
        train_hi_words = [tok for line in f for tok in line.strip().split()]
    with open(out_dir / "test.hi", "r", encoding="utf-8") as f:
        test_hi_words = [tok for line in f for tok in line.strip().split()]

    train_hi_vocab = set(train_hi_words)
    test_hi_vocab = set(test_hi_words)
    hi_oov = test_hi_vocab - train_hi_vocab

    print(f"\nHieroglyph Word Vocab:")
    print(f"  Train unique words     : {len(train_hi_vocab):,}")
    print(f"  Test unique words      : {len(test_hi_vocab):,}")
    print(f"  Test OOV words         : {len(hi_oov)} ({len(hi_oov)/len(test_hi_vocab):.2%})")

    print("\nSample Preprocessed Pairs (First 3):")
    with open(out_dir / "train.my") as f_my, open(out_dir / "train.hi") as f_hi:
        for i in range(3):
            print(f"  [{i+1}] MY: {f_my.readline().strip()}")
            print(f"      HI: {f_hi.readline().strip()}")

    print("\n[SUCCESS] Preprocessing completed successfully.")


if __name__ == "__main__":
    main()

