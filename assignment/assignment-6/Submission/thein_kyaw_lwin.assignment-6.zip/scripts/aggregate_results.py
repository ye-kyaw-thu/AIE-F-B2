#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
aggregate_results.py
====================
Aggregates experimental results from Phase 1 (Word-Level) and Phase 2 (Character-Level)
for both Myanmar -> Hieroglyphs and Hieroglyphs -> Myanmar.
Outputs comprehensive Markdown comparison tables for Assignment 6 report.
"""

from pathlib import Path


def main():
    print("=" * 105)
    print("ASSIGNMENT 6: COMPREHENSIVE EXPERIMENT RESULTS (PHASE 1 & PHASE 2)")
    print("=" * 105)

    # -----------------------------------------------------------------------
    # Phase 1 Summary
    # -----------------------------------------------------------------------
    print("\n### Table 1: Phase 1 — Word-Level Hieroglyphics (Baseline & Heterogeneous Ensemble)\n")
    print("| Direction | Architecture / Setup | Test BLEU | Brevity Penalty | 1-Gram Prec. | Training Time | Exact Matches | Match % |")
    print("|---|---|---|---|---|---|---|---|")
    print("| Myanmar → Hiero | Seq2Seq (Bi-LSTM Baseline) | 17.9687 | 1.0000 | 50.15% | 49.45 min | 29 / 500 | 5.80% |")
    print("| Myanmar → Hiero | **Transformer (Self-Attention)** | **32.8097** | 0.9955 | 60.03% | **7.82 min** | **103 / 500** | **20.60%** |")
    print("| Myanmar → Hiero | Ensemble (S2S + Transformer) | 30.4026 | 0.9968 | 58.74% | — (Inference) | 92 / 500 | 18.40% |")
    print("| Hiero → Myanmar | Seq2Seq (Bi-LSTM Baseline) | 42.8069 | 1.0000 | 73.19% | 50.98 min | 32 / 500 | 6.40% |")
    print("| Hiero → Myanmar | **Transformer (Self-Attention)** | **53.2801** | 0.9797 | 78.49% | **9.46 min** | 36 / 500 | 7.20% |")
    print("| Hiero → Myanmar | **Ensemble (S2S + Transformer)** | **53.1680** | 0.9789 | 78.43% | — (Inference) | **40 / 500** | **8.00%** |")

    # -----------------------------------------------------------------------
    # Phase 2 Summary
    # -----------------------------------------------------------------------
    print("\n### Table 2: Phase 2 — Character-Level Hieroglyphics & Complete Ensemble Suite\n")
    print("#### Part A: Myanmar (Syllables) → Hieroglyphs (Characters with '_' word boundary)")
    print("| Model / Ensemble Configuration | Setup | Char BLEU | Word BLEU | BP | 1-Gram Prec. | Train Time | Exact Matches | Match % |")
    print("|---|---|---|---|---|---|---|---|---|")
    print("| Seq2Seq-1 | Seed 1111 | 51.6006 | 23.4728 | 0.9917 | 51.15% | 31.79 min | 63 / 500 | 12.60% |")
    print("| Seq2Seq-2 | Seed 2222 | 54.9672 | 27.1084 | 1.0000 | 54.33% | 31.87 min | 78 / 500 | 15.60% |")
    print("| Transformer-1 | Seed 1111 (Base) | 58.3069 | 29.6521 | 1.0000 | 57.36% | **4.79 min** | 96 / 500 | 19.20% |")
    print("| Transformer-2 | Seed 2222 (Warmup) | 56.6105 | 27.1094 | 1.0000 | 56.45% | **5.45 min** | 84 / 500 | 16.80% |")
    print("| **Ensemble A: tr1 + tr2** | Homogeneous Trans | 59.2976 | **31.8947** | 0.9943 | 59.21% | — | 104 / 500 | 20.80% |")
    print("| **Ensemble B: seq1 + seq2** | Homogeneous S2S | 54.1951 | 26.4962 | 0.9962 | 53.92% | — | 76 / 500 | 15.20% |")
    print("| **Ensemble C: seq2seq + trans** | Heterogeneous S2S+Tr | 58.1376 | **32.0367** | 0.9898 | 58.45% | — | 98 / 500 | 19.60% |")
    print("| **Ensemble D: All 4 Models** | Quad-Model Ensemble | **59.7519** | **33.8746** | 0.9846 | **60.17%** | — | **108 / 500** | **21.60%** |")

    print("\n#### Part B: Hieroglyphs (Characters) → Myanmar (Syllables)")
    print("| Model / Ensemble Configuration | Setup | Syl BLEU | BP | 1-Gram Prec. | Train Time | Exact Matches (Detok) | Match % | Relative Gain |")
    print("|---|---|---|---|---|---|---|---|---|")
    print("| Seq2Seq-1 | Seed 1111 | 35.8540 | 1.0000 | 59.26% | 28.16 min | 73 / 500 | 14.60% | Single baseline |")
    print("| Seq2Seq-2 | Seed 2222 | 36.2778 | 1.0000 | 60.31% | 28.54 min | 74 / 500 | 14.80% | Single baseline |")
    print("| Transformer-1 | Seed 1111 (Base) | 38.7990 | 0.9836 | 63.01% | **3.66 min** | 78 / 500 | 15.60% | Single baseline |")
    print("| Transformer-2 | Seed 2222 (Warmup) | 40.0098 | 0.9822 | 63.60% | **4.73 min** | 87 / 500 | 17.40% | Best Single Model |")
    print("| **Ensemble A: tr1 + tr2** | Homogeneous Trans | **41.1178** | 0.9842 | 64.22% | — | 93 / 500 | 18.60% | **+1.11 BLEU** vs Tr-2 |")
    print("| **Ensemble B: seq1 + seq2** | Homogeneous S2S | **36.7340** | 1.0000 | 60.23% | — | 80 / 500 | 16.00% | **+0.46 BLEU** vs S2S-2 |")
    print("| **Ensemble C: seq2seq + trans** | Heterogeneous S2S+Tr | **43.7386** | 0.9943 | 65.34% | — | 102 / 500 | 20.40% | **+3.73 BLEU** vs Tr-2 |")
    print("| **Ensemble D: All 4 Models** | Quad-Model Ensemble | **44.1416** | 1.0000 | **65.62%** | — | **103 / 500** | **20.60%** | **+4.13 BLEU Peak Score** |")

    print("\n" + "=" * 105)


if __name__ == "__main__":
    main()
