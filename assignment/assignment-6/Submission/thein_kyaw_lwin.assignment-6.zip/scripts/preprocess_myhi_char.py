#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
preprocess_myhi_char.py
=======================
Preprocesses parallel corpus with:
  - Myanmar (.my): Syllable-level tokenization via sylbreak regex (1,079 vocab)
  - Hieroglyphs (.hi): Character-level tokenization with '_' word boundary (37 vocab, 0% OOV)
  
Generates 'myhi-char-par/' dataset ready for Kaggle dataset upload.
"""

import os
import re
import sys
import json
import shutil
from pathlib import Path

MY_CONSONANT = r"က-အ"
EN_CHAR = r"a-zA-Z0-9"
SS_SYMBOL = "္"
ATHAT = "်"
OTHER_CHAR = r"ဣဤဥဦဧဩဪဿ၌၍၎၏၀-၉႐-႙၊။!-/:-@[-`’“”{-~\s…"

SYLBREAK_PATTERN = re.compile(
    rf"((?<!{SS_SYMBOL})[{MY_CONSONANT}](?![{ATHAT}{SS_SYMBOL}])|[{EN_CHAR}{OTHER_CHAR}])"
)


def break_syllables(text: str) -> str:
    """Segment Myanmar text into space-separated syllables."""
    text_clean = re.sub(r"\s+", "", str(text))
    segmented = SYLBREAK_PATTERN.sub(lambda m: " " + m.group(1), text_clean)
    return re.sub(r"^\s+|\s+$", "", segmented)


def hi_to_char_tokens(text: str) -> str:
    """Segment Hieroglyphic text into characters with '_' word boundaries."""
    words = text.strip().split()
    return " _ ".join(" ".join(list(w)) for w in words)


def char_tokens_to_hi(text: str) -> str:
    """Lossless reconstruction of word-level Hieroglyphic text from character tokens."""
    parts = text.strip().split("_")
    return " ".join("".join(p.split()) for p in parts)


def main():
    base_dir = Path(__file__).resolve().parent.parent
    raw_dir = base_dir / "myhi_data"
    out_dir = base_dir / "myhi-char-par"

    print("=" * 75)
    print("PREPROCESSING: SYLLABLE-LEVEL MYANMAR + CHAR-LEVEL HIEROGLYPHS")
    print("=" * 75)

    if not raw_dir.exists():
        print(f"[ERROR] Raw data directory not found: {raw_dir}", file=sys.stderr)
        sys.exit(1)

    out_dir.mkdir(parents=True, exist_ok=True)

    splits = [
        ("train", "train"),
        ("valid", "dev"),
        ("valid", "valid"),
        ("test", "test"),
    ]

    for src_split, dst_name in splits:
        src_my_path = raw_dir / f"{src_split}.my"
        src_hi_path = raw_dir / f"{src_split}.hi"
        dst_my_path = out_dir / f"{dst_name}.my"
        dst_hi_path = out_dir / f"{dst_name}.hi"

        with open(src_my_path, "r", encoding="utf-8") as f_my, \
             open(src_hi_path, "r", encoding="utf-8") as f_hi:
            my_lines = [l.strip() for l in f_my]
            hi_lines = [l.strip() for l in f_hi]

        syl_my = [break_syllables(l) for l in my_lines]
        char_hi = [hi_to_char_tokens(l) for l in hi_lines]

        # Verify roundtrip
        for orig, char_tok in zip(hi_lines[:100], char_hi[:100]):
            assert char_tokens_to_hi(char_tok) == " ".join(orig.split()), "Roundtrip verification failed!"

        with open(dst_my_path, "w", encoding="utf-8") as f_out:
            for l in syl_my:
                f_out.write(l + "\n")

        with open(dst_hi_path, "w", encoding="utf-8") as f_out:
            for l in char_hi:
                f_out.write(l + "\n")

        print(f"  [OK] Processed {src_split} -> {dst_name}: {len(syl_my)} pairs")

    # Save original references for detokenized word-level evaluation
    shutil.copy2(raw_dir / "test.my", out_dir / "test.my.raw")
    shutil.copy2(raw_dir / "test.hi", out_dir / "test.hi.raw")
    print(f"  [OK] Saved test.my.raw and test.hi.raw")

    # Generate Kaggle dataset-metadata.json
    metadata = {
        "title": "myhi-char-par",
        "id": "theinkyawlwin/myhi-char-par",
        "licenses": [{"name": "CC0-1.0"}],
        "keywords": ["nlp", "neural-machine-translation", "myanmar", "hieroglyphics", "marian-nmt"]
    }
    with open(out_dir / "dataset-metadata.json", "w", encoding="utf-8") as f_meta:
        json.dump(metadata, f_meta, indent=2)
    print(f"  [OK] Generated {out_dir / 'dataset-metadata.json'}")

    # Vocabulary Stats
    with open(out_dir / "train.my") as f:
        my_train_tokens = [tok for l in f for tok in l.strip().split()]
    with open(out_dir / "test.my") as f:
        my_test_tokens = [tok for l in f for tok in l.strip().split()]

    with open(out_dir / "train.hi") as f:
        hi_train_tokens = [tok for l in f for tok in l.strip().split()]
    with open(out_dir / "test.hi") as f:
        hi_test_tokens = [tok for l in f for tok in l.strip().split()]

    print("\n--- Vocabulary & OOV Statistics ---")
    print(f"Myanmar Syllable Vocab     : {len(set(my_train_tokens))} unique tokens | Test OOV: {len(set(my_test_tokens) - set(my_train_tokens))} ({len(set(my_test_tokens) - set(my_train_tokens))/len(set(my_test_tokens)):.2%})")
    print(f"Hieroglyph Char Vocab      : {len(set(hi_train_tokens))} unique tokens | Test OOV: {len(set(hi_test_tokens) - set(hi_train_tokens))} ({len(set(hi_test_tokens) - set(hi_train_tokens))/len(set(hi_test_tokens)):.2%})")
    print("\nSample Pair:")
    with open(out_dir / "train.my") as f_my, open(out_dir / "train.hi") as f_hi:
        print(f"  MY (Syllables) : {f_my.readline().strip()}")
        print(f"  HI (Characters): {f_hi.readline().strip()}")

    print("\n[SUCCESS] Preprocessing completed successfully!")


if __name__ == "__main__":
    main()

