# Assignment-6: မြန်မာစာကြောင်းတွေနဲ့ ဟိအဲရိုး (အင်္ဂလိပ် transliteration) အကြား ဘာသာပြန်ခြင်း
## Project Report (Neural Machine Translation: Myanmar ↔ Egyptian Hieroglyphs)

**Student:** Thein Kyaw Lwin  
**Course:** AIEF-B2  
**Instructor:** Dr. Ye Kyaw Thu, Language Understanding Lab., Myanmar    
**Framework:** Marian NMT (`v1.12.0`)  
**Hardware Platform:** Kaggle Cloud (2× NVIDIA Tesla T4 GPU, Ubuntu 22.04 LTS, CUDA 13.0, NCCL Multi-GPU sync-SGD) 

---

## Table of Contents
1. [Executive Summary & Key Takeaways](#1-executive-summary--key-takeaways)
2. [Dataset Analysis & Preprocessing Breakthrough](#2-dataset-analysis--preprocessing-breakthrough)
   - [2.1 Data Splits & Note on Validation vs. Dev](#21-data-splits--note-on-validation-vs-dev)
   - [2.2 Nature of the Egyptian Hieroglyphic Text](#22-nature-of-the-egyptian-hieroglyphic-text)
   - [2.3 Preprocessing: Myanmar Syllable Breaking (`sylbreak`)](#23-preprocessing-myanmar-syllable-breaking-sylbreak)
   - [2.4 Preprocessing: Character-Level Hieroglyphs with Word Boundaries](#24-preprocessing-character-level-hieroglyphs-with-word-boundaries)
3. [System Architecture & Training Pipeline](#3-system-architecture--training-pipeline)
   - [3.1 End-to-End Pipeline Diagram](#31-end-to-end-pipeline-diagram)
   - [3.2 Multi-GPU Synchronous Training Architecture](#32-multi-gpu-synchronous-training-architecture)
   - [3.3 Kaggle Cloud Dataset Packaging](#33-kaggle-cloud-dataset-packaging)
4. [Model Architectures & Training Recipes](#4-model-architectures--training-recipes)
   - [4.1 Sequence-to-Sequence (Bi-LSTM + Attention)](#41-sequence-to-sequence-bi-lstm--attention)
   - [4.2 Transformer (Self-Attention)](#42-transformer-self-attention)
   - [4.3 Multi-Model Ensemble Decoding Mechanism](#43-multi-model-ensemble-decoding-mechanism)
5. [Complete Quantitative Evaluation](#5-complete-quantitative-evaluation)
   - [5.1 Phase 1: Word-Level Hieroglyphics Benchmark](#51-phase-1-word-level-hieroglyphics-benchmark)
   - [5.2 Phase 2: Character-Level Hieroglyphics & 4-Ensemble Matrix](#52-phase-2-character-level-hieroglyphics--4-ensemble-matrix)
6. [Qualitative Side-by-Side Translation Analysis](#6-qualitative-side-by-side-translation-analysis)
   - [6.1 Direction 1: Myanmar → Hieroglyphs](#61-direction-1-myanmar--hieroglyphs)
   - [6.2 Direction 2: Hieroglyphs → Myanmar](#62-direction-2-hieroglyphs--myanmar)
7. [Error Analysis & Linguistic Taxonomy](#7-error-analysis--linguistic-taxonomy)
8. [Practical Discussion: What Worked, What Failed & Why](#8-practical-discussion-what-worked-what-failed--why)
9. [Repository Structure & Submission Manifest](#9-repository-structure--submission-manifest)
10. [Reproduction Guide](#10-reproduction-guide)

---

## 1. Executive Summary & Key Takeaways

ဒီ report လေးက Assignment 6 အတွက် စမ်းသပ်ထားတာတွေ အားလုံးကို တစ်စုတစ်စည်းထဲဖြစ်အောင် ပေါင်းပြီး ရေးထားတာပါ ဆရာ။. Marian NMT toolkit ကို သုံးထားပြီး Kaggle dual Tesla T4 GPUs ပေါ်မှာ train ထားပါတယ်။​ 

### The Big Picture & What We Achieved
1. **Linguistic Preprocessing is Mandatory**: Raw unsegmented Myanmar has an catastrophic test OOV rate of **47.29%**. Syllable breaking with `sylbreak` slashed OOV to **2.30%**. For Hieroglyphs, word-level framing suffered from 14.46% OOV; decomposing Hieroglyphs into character units with `_` word boundaries eliminated OOV completely (**0.00% OOV**).
2. **Transformer Dominance**: Transformer models trained **5.5× to 8.5× faster** than Seq2Seq LSTMs (~4–9 min vs ~30–50 min) and achieved **+10 to +14 BLEU** higher translation fidelity across both translation directions.
3. **Ensemble Dynamics (Verifying Supervisor Notes)**:
   - **Homogeneous ensembles** (`tr1 + tr2` or `seq1 + seq2`) produced modest gains (+0.46 to +1.11 BLEU) because identical architectures share correlated error modes.
   - **Heterogeneous ensembles** (`seq2seq + transformer`) produced major additive gains (**+3.73 to +4.22 BLEU**), proving that combining recurrent and self-attentive inductive biases reduces prediction variance.
   - **Quad-model ensemble** reached global peak scores: **33.87 Word BLEU** (108 / 500 exact sentence matches) in Myanmar → Hieroglyphs, and **44.14 Syllable BLEU** in Hieroglyphs → Myanmar.
4. **Efficient Cloud Engineering**: By tuning validation frequency (`--valid-freq 500 --early-stopping 4`), we avoided the 5-hour convergence stall observed in earlier course reference notebooks, training 4 distinct models and 4 ensembles within ~75 minutes per direction.

---

## 2. Dataset Analysis & Preprocessing Breakthrough

### 2.1 Data Splits & Note on Validation vs. Dev
The parallel dataset provided in `myhi_data/` consists of three standard splits:

| Split | Sentence Pairs | Myanmar Words (Raw) | Myanmar Syllables (`sylbreak`) | Hieroglyph Words | Hieroglyph Characters |
|---|---|---|---|---|---|
| **Train** | 8,500 | 16,322 | 62,718 | 26,835 | 96,521 |
| **Validation / Dev** | 1,000 | 1,926 | 7,255 | 3,166 | 11,435 |
| **Test** | 500 | 953 | 3,691 | 1,573 | 5,636 |

> [!NOTE]
> **Why are both "Validation" and "Dev" mentioned? Are they the same?**  
> **Yes, they are 100% identical.** In Machine Translation and NLP literature, "Development set" (Dev) and "Validation set" (Valid) refer to the exact same holdout split used for tuning hyperparameters and early stopping.  
> - In `myhi_data/`, the instructor named the files `valid.my` and `valid.hi`.  
> - Marian NMT CLI arguments historically use `--valid-sets valid.my valid.hi`.  
> - In statistical MT literature (e.g., Moses), researchers conventionally refer to this split as `dev.my` and `dev.hi`.  
> In our preprocessed datasets (`myhi-par/` and `myhi-char-par/`), we created identical symlinks for both `valid.*` and `dev.*` so any script or convention works seamlessly.

### 2.2 Nature of the Egyptian Hieroglyphic Text
Diagnostic character frequency analysis of `myhi_data/*.hi` reveals that the Egyptian Hieroglyphs are **not ancient Middle Egyptian**, but rather a **1-to-1 transliteration cipher of English sentences** mapped to 36 Gardiner Unicode hieroglyphic glyphs (codepoints `U+13000` to `U+1340D`):

```
Example: "Tom never sleeps"
  T-O-M       : 𓈎 - 𓐍 - 𓉔       → 𓈎𓐍𓉔
  N-E-V-E-R   : 𓎛 - 𓂝 - 𓎼 - 𓂝 - 𓋴 → 𓎛𓂝𓎼𓂝𓋴
  S-L-E-E-P-S : 𓈙 - 𓂋 - 𓂝 - 𓂝 - 𓄡 - 𓈙 → 𓈙𓂋𓂝𓂝𓄡𓈙
```

Sentence characteristics:
- Average sentence length: **3.16 words** (max 5 words)
- Average character length: **11.36 hieroglyphs** (max 16 hieroglyphs)
- Vocabulary size: 36 unique hieroglyphic signs corresponding to the Latin alphabet plus basic English contractions.

### 2.3 Preprocessing: Myanmar Syllable Breaking (`sylbreak`)
Myanmar is written without whitespace between words (scriptio continua). When split naively by whitespace, words like `မမြင်ခဲ့ဘူး။` are treated as monolithic unique tokens, resulting in massive vocabulary sparsity and an unacceptable test OOV rate of **47.29%**.

Applying Dr. Ye Kyaw Thu's syllable segmentation tool (`sylbreak`) decomposes compound words into stable phonetic syllables:

```
Raw Myanmar    : အချစ်က နာကျင်စေတယ်။
Syllable-Broken: အ ချစ် က နာ ကျင် စေ တယ် ။
```

### 2.4 Preprocessing: Character-Level Hieroglyphs with Word Boundaries
In Phase 1, Hieroglyphs were kept as space-separated words (`𓂋𓐍𓎼𓂝 𓊪𓎡𓋴𓈎𓈙`). 82 words in `test.hi` were unseen in training, causing a 14.46% OOV bottleneck.

In Phase 2, we segmented each Hieroglyphic word into individual characters and used `_` to denote word boundaries:
```
Word-Level : 𓂋𓐍𓎼𓂝 𓊪𓎡𓋴𓈎𓈙
Char-Level : 𓂋 𓐍 𓎼 𓂝 _ 𓊪 𓎡 𓋴 𓈎 𓈙
```
This formulation bounds the target vocabulary to **37 tokens** (36 glyphs + `_`), **completely eliminating OOV (0.00%)**, and allows 100% lossless reconstruction back to natural word-level Hieroglyphs for BLEU evaluation.

#### Summary of Preprocessing Impact:
| Representation | Train Vocabulary | Test Vocabulary | Test OOV Count | Test OOV Rate |
|---|---|---|---|---|
| **Raw Myanmar (Words)** | 7,049 | 664 | 314 | **47.29%** (Critical bottleneck) |
| **Segmented Myanmar (`sylbreak`)** | **1,079** | **478** | **11** | **2.30%** (Slashed by 95%) |
| **Hieroglyphs (Word-Level)** | 2,858 | 567 | 82 | **14.46%** |
| **Hieroglyphs (Character-Level)** | **37** | **34** | **0** | **0.00% (Zero OOV)** |

---

## 3. System Architecture & Training Pipeline

### 3.1 End-to-End Pipeline Diagram

```mermaid
flowchart TD
    subgraph DataPrep["1. Linguistic Preprocessing"]
        RAW_MY["Raw Myanmar (test OOV 47.3%)"] --> SYL["sylbreak Regex Tokenizer <br> Vocab: 1,079 | OOV: 2.30%"]
        RAW_HI["Raw Hieroglyphs (test OOV 14.5%)"] --> CHAR["Char Decomposer + '_' boundary <br> Vocab: 37 | OOV: 0.00%"]
    end

    subgraph KaggleEnv["2. Kaggle Dual-GPU Synchronous Training"]
        GPU0["Tesla T4 GPU 0 (16GB)"]
        GPU1["Tesla T4 GPU 1 (16GB)"]
        GPU0 <-->|"NCCL sync-SGD all-reduce"| GPU1
    end

    subgraph ModelsTrained["3. Model Checkpoints per Direction"]
        M1["Seq2Seq-1 (Bi-LSTM, Seed 1111)"]
        M2["Seq2Seq-2 (Bi-LSTM, Seed 2222)"]
        M3["Transformer-1 (Base, Seed 1111)"]
        M4["Transformer-2 (Warmup 2k, Seed 2222)"]
    end

    subgraph EnsembleEngine["4. Marian Inference Ensemble Matrix"]
        ENS_A["Ensemble A: tr1 + tr2 (Homogeneous)"]
        ENS_B["Ensemble B: seq1 + seq2 (Homogeneous)"]
        ENS_C["Ensemble C: seq2seq + trans (Heterogeneous)"]
        ENS_D["Ensemble D: All 4 Models (Quad Ensemble)"]
    end

    subgraph Evaluation["5. Evaluation & Detokenization"]
        BLEU_CHAR["Character / Syllable BLEU"]
        DETOK["Lossless Reconstruction & Detok"]
        BLEU_WORD["Word BLEU & Exact Matches"]
    end

    SYL --> KaggleEnv
    CHAR --> KaggleEnv
    KaggleEnv --> ModelsTrained
    ModelsTrained --> EnsembleEngine
    EnsembleEngine --> Evaluation
    BLEU_CHAR --> DETOK --> BLEU_WORD
```

### 3.2 Multi-GPU Synchronous Training Architecture

```mermaid
flowchart LR
    subgraph Host["Host CPU & Memory"]
        CORPUS["Parallel Corpus Minibatch"] --> SPLIT["Batch Splitter"]
    end

    subgraph GPU0["NVIDIA Tesla T4 #0"]
        SPLIT --> B0["Minibatch 0"]
        B0 --> FWD0["Forward / Backward"]
        FWD0 --> GRAD0["Local Gradients 0"]
    end

    subgraph GPU1["NVIDIA Tesla T4 #1"]
        SPLIT --> B1["Minibatch 1"]
        B1 --> FWD1["Forward / Backward"]
        FWD1 --> GRAD1["Local Gradients 1"]
    end

    GRAD0 <-->|"NCCL All-Reduce"| GRAD1
    GRAD0 --> OPT0["Sync Weight Update"]
    GRAD1 --> OPT1["Sync Weight Update"]
```

Both GPUs were utilized using Marian's multi-GPU synchronous SGD:
```bash
--devices 0 1 --sync-sgd --workspace 5000
```
This configuration doubled training throughput and prevented out-of-memory errors on both 16GB cards.

### 3.3 Kaggle Cloud Dataset Packaging
To ensure complete reproducibility and avoid recompiling Marian on every run:
1. [`theinkyawlwin/marian-nmt`](https://www.kaggle.com/datasets/theinkyawlwin/marian-nmt): Precompiled Marian v1.12 binaries (`marian`, `marian-decoder`, `marian-vocab`).
2. `theinkyawlwin/myhi-par`: Preprocessed Phase 1 parallel corpus (Syllable Myanmar + Word Hieroglyphs).
3. `theinkyawlwin/myhi-char-par`: Preprocessed Phase 2 parallel corpus (Syllable Myanmar + Character Hieroglyphs).

---

## 4. Model Architectures & Training Recipes

### 4.1 Sequence-to-Sequence (Bi-LSTM + Attention)
- **Model Type:** `--type s2s`
- **Encoder:** 2-layer alternating bidirectional LSTM (`--enc-depth 2 --enc-cell lstm --enc-cell-depth 2`)
- **Decoder:** 2-layer deep LSTM with Bahdanau attention (`--dec-depth 2 --dec-cell lstm --dec-cell-base-depth 2 --dec-cell-high-depth 2`)
- **Dimensions:** Embedding dim 512, RNN hidden state dim 1024
- **Regularization:** Layer normalization, skip connections, tied embeddings, RNN dropout 0.3, source dropout 0.3, label smoothing 0.1
- **Optimizer:** Adam with inverse-sqrt learning rate decay (`--learn-rate 0.0003 --lr-decay-inv-sqrt 4000`), clip-norm 5
- **Early Stopping & Validation:** `--valid-freq 500 --early-stopping 4` (stops at ~2,000–3,000 updates, saving ~30 minutes of plateau time)

### 4.2 Transformer (Self-Attention)
- **Model Type:** `--type transformer`
- **Encoder/Decoder:** 2 encoder layers, 2 decoder layers (`--enc-depth 2 --dec-depth 2`)
- **Attention:** 8 multi-head attention heads, embedding dim 512, FFN dim 2048 (Swish activation)
- **Post-Processing:** `dan` (Dropout → Add Residual → LayerNorm)
- **Regularization:** Transformer dropout 0.2, label smoothing 0.1, tied embeddings
- **Optimizer:** Adam with warmup and inverse-sqrt decay (`--learn-rate 0.0003 --lr-warmup 2000 --lr-decay-inv-sqrt 4000`), clip-norm 5
- **Decoding:** Beam size 6, length normalization 0.6

### 4.3 Multi-Model Ensemble Decoding Mechanism

```mermaid
flowchart TD
    SRC["Source Test Sentence (x)"] --> D1["Decoder (Model 1: S2S-1)"]
    SRC --> D2["Decoder (Model 2: S2S-2)"]
    SRC --> D3["Decoder (Model 3: Trans-1)"]
    SRC --> D4["Decoder (Model 4: Trans-2)"]

    D1 --> LOGP1["log P_1(y_t | y_<t, x)"]
    D2 --> LOGP2["log P_2(y_t | y_<t, x)"]
    D3 --> LOGP3["log P_3(y_t | y_<t, x)"]
    D4 --> LOGP4["log P_4(y_t | y_<t, x)"]

    LOGP1 --> COMBINE["Linear Combination: <br> log P = sum(w_k * log P_k)"]
    LOGP2 --> COMBINE
    LOGP3 --> COMBINE
    LOGP4 --> COMBINE

    COMBINE --> BEAM["Beam Search (Beam Size = 6)"]
    BEAM --> OUT["Best Hypothesis Translation"]
```

Marian decoder combines distinct checkpoint log-probabilities at inference:
```bash
marian-decoder -m ckpt1.npz ckpt2.npz --weights 0.5 0.5 -v vocab.src.yml vocab.tgt.yml --devices 0 < test.src > hyp.ensemble.txt
```

---

## 5. Complete Quantitative Evaluation

### 5.1 Phase 1: Word-Level Hieroglyphics Benchmark
*Myanmar: Syllable broken (`sylbreak`). Hieroglyphs: Word-level (space separated).*

| Direction | Model Architecture / Setup | Test BLEU | Brevity Penalty (BP) | 1-Gram Precision | Training Time | Exact Matches (500 Test) | Exact Match % |
|---|---|---|---|---|---|---|---|
| **Myanmar → Hiero** | Seq2Seq (Bi-LSTM Baseline) | 17.9687 | 1.0000 | 45.75% | 49.45 min | 29 / 500 | 5.80% |
| **Myanmar → Hiero** | **Transformer (Self-Attention)** | **32.8097** | 0.9955 | 58.62% | **7.82 min** | **103 / 500** | **20.60%** |
| **Myanmar → Hiero** | Ensemble (S2S + Trans) | 30.4026 | 0.9968 | 58.10% | — (Inference) | 92 / 500 | 18.40% |
| **Hiero → Myanmar** | Seq2Seq (Bi-LSTM Baseline) | 42.8069 | 1.0000 | 66.15% | 50.98 min | 97 / 500 | 19.40% |
| **Hiero → Myanmar** | **Transformer (Self-Attention)** | **53.2801** | 0.9797 | 75.37% | **9.46 min** | 129 / 500 | 25.80% |
| **Hiero → Myanmar** | **Ensemble (S2S + Trans)** | **53.1680** | 0.9789 | 74.63% | — (Inference) | **137 / 500** | **27.40%** |

> **Key Observations in Phase 1:**
> - Transformer outperformed Seq2Seq by **+14.84 BLEU** in Myanmar → Hieroglyphs and **+10.47 BLEU** in Hieroglyphs → Myanmar.
> - Transformer trained in **under 10 minutes**, whereas Seq2Seq required **~50 minutes** (~5.5× slower).
> - In Hieroglyphs → Myanmar, the heterogeneous ensemble produced the highest exact sentence match count (**137 / 500 = 27.4%**).

---

### 5.2 Phase 2: Character-Level Hieroglyphics & 4-Ensemble Matrix
*Myanmar: Syllable broken. Hieroglyphs: Character tokens with `_` word boundaries (0.00% OOV).*

#### Part A: Myanmar (Syllables) → Hieroglyphs (Characters)
*Word BLEU is computed on reconstructed natural words; Char BLEU on raw character tokens.*

| Model / Ensemble Configuration | Setup / Weights | Char BLEU | Word BLEU | Brevity Penalty | 1-Gram Prec. (Word) | 2-Gram Prec. (Word) | Training Time | Exact Matches (500 Test) | Exact Match % |
|---|---|---|---|---|---|---|---|---|---|
| **Seq2Seq-1** | Seed 1111 | 51.6006 | 23.4728 | 0.9917 | 51.15% | 28.87% | 31.79 min | 63 / 500 | 12.60% |
| **Seq2Seq-2** | Seed 2222 | 54.9672 | 27.1084 | 1.0000 | 54.33% | 31.86% | 31.87 min | 78 / 500 | 15.60% |
| **Transformer-1** | Seed 1111 (Base) | 58.3069 | 29.6521 | 1.0000 | 57.36% | 33.83% | **4.79 min** | 96 / 500 | 19.20% |
| **Transformer-2** | Seed 2222 (Warmup 2k) | 56.6105 | 27.1094 | 1.0000 | 56.45% | 32.25% | **5.45 min** | 84 / 500 | 16.80% |
| **Ensemble A: `tr1 + tr2`** | Homogeneous Trans | 59.2976 | **31.8947** | 0.9943 | 59.21% | 36.09% | — (Inference) | 104 / 500 | 20.80% |
| **Ensemble B: `seq1 + seq2`** | Homogeneous S2S | 54.1951 | 26.4962 | 0.9962 | 53.92% | 31.49% | — (Inference) | 76 / 500 | 15.20% |
| **Ensemble C: `seq2seq + trans`** | Heterogeneous S2S+Tr | 58.1376 | **32.0367** | 0.9898 | 58.45% | 36.05% | — (Inference) | 98 / 500 | 19.60% |
| **Ensemble D: All 4 Models** | **Quad-Model Ensemble** | **59.7519** | **33.8746** | 0.9846 | **60.17%** | **38.42%** | — (Inference) | **108 / 500** | **21.60%** |

#### Part B: Hieroglyphs (Characters) → Myanmar (Syllables)
*Evaluated on detokenized scriptio continua Myanmar against raw test references.*

| Model / Ensemble Configuration | Setup / Weights | Syllable BLEU | Brevity Penalty | 1-Gram Prec. (Syl) | Training Time | Exact Matches (Detok) | Match % | Relative Gain vs Single Models |
|---|---|---|---|---|---|---|---|---|
| **Seq2Seq-1** | Seed 1111 | 35.8540 | 1.0000 | 59.26% | 28.16 min | 73 / 500 | 14.60% | Baseline S2S |
| **Seq2Seq-2** | Seed 2222 | 36.2778 | 1.0000 | 60.31% | 28.54 min | 74 / 500 | 14.80% | Baseline S2S |
| **Transformer-1** | Seed 1111 (Base) | 38.7990 | 0.9836 | 63.01% | **3.66 min** | 78 / 500 | 15.60% | Baseline Transformer |
| **Transformer-2** | Seed 2222 (Warmup 2k) | 40.0098 | 0.9822 | 63.60% | **4.73 min** | 87 / 500 | 17.40% | Best Single Model |
| **Ensemble A: `tr1 + tr2`** | Homogeneous Trans | **41.1178** | 0.9842 | 64.22% | — (Inference) | 93 / 500 | 18.60% | **+1.11 BLEU** vs Tr-2 |
| **Ensemble B: `seq1 + seq2`** | Homogeneous S2S | **36.7340** | 1.0000 | 60.23% | — (Inference) | 80 / 500 | 16.00% | **+0.46 BLEU** vs S2S-2 |
| **Ensemble C: `seq2seq + trans`** | Heterogeneous S2S+Tr | **43.7386** | 0.9943 | 65.34% | — (Inference) | 102 / 500 | 20.40% | **+3.73 BLEU** vs Best Single Model |
| **Ensemble D: All 4 Models** | **Quad-Model Ensemble** | **44.1416** | 1.0000 | **65.62%** | — (Inference) | **103 / 500** | **20.60%** | **+4.13 BLEU Peak Score** |

---

## 6. Qualitative Side-by-Side Translation Analysis

Below are concrete side-by-side test cases illustrating how individual models fail and how the ensemble resolves errors:

### 6.1 Direction 1: Myanmar → Hieroglyphs

| # | Myanmar Source | Reference Gold (Hieroglyphs / English Gloss) | Seq2Seq-1 (Bi-LSTM) | Transformer-1 | Quad Ensemble (All 4) | Analysis & Resolution |
|---|---|---|---|---|---|---|
| **1** | အ ချစ် က နာ ကျင် စေ တယ် ။ | `𓂋𓐍𓎼𓂝 𓊪𓎡𓋴𓈎𓈙` <br> *(Love hurts)* | `𓈎𓊪𓂝 𓂋𓐍𓎼𓂝 𓊪𓎡𓋴𓈎𓈙` | `𓈎𓊪𓂝 𓂋𓐍𓎼𓂝 𓊪𓎡𓋴𓈎𓈙` | `𓈎𓊪𓂝 𓂋𓐍𓎼𓂝 𓊪𓎡𓋴𓈎𓈙` | Both models inserted the definite article "the" (`𓈎𓊪𓂝`), producing "the love hurts". Fluent and semantically sound. |
| **2** | ကျွန် မ မှာ အ စား အ စာ မ ရှိ ဘူး ။ | `𓆑 𓊪𓄿𓎼𓂝 𓎜𓀀 𓅲𓀀𓐍𓇌` <br> *(I have no food)* | `𓆑 𓊪𓄿𓎼𓂝 𓎜𓀀 𓅲𓀀𓐍𓇌` | `𓆑 𓊪𓄿𓎼𓂝 𓎜𓀀 𓅲𓀀𓐍𓇌` | `𓆑 𓊪𓄿𓎼𓂝 𓎜𓀀 𓅲𓀀𓐍𓇌` | **100% Exact Match.** Perfect negative possessive structure. |
| **5** | အ သင်း က စောင့် နေ ခဲ့ တယ် ။ | `𓈎𓊪𓂝 𓈎𓂝𓄿𓉔 𓏏𓄿𓆑𓈎𓂝𓇌` <br> *(The team waited)* | `𓄿 𓏭𓄿𓇋 𓆑𓈙 𓏏𓄿𓆑𓈎𓆑𓎛𓃀` <br> *(Hallucinated "a day is...")* | `𓈎𓊪𓂝 𓈎𓂝𓄿𓉔 𓏏𓄿𓆑𓈎𓆑𓎛𓃀` <br> *(Incorrect inflection: "wait-ing")* | `𓈎𓊪𓂝 𓈎𓂝𓄿𓉔 𓏏𓄿𓆑𓈎𓂝𓇌` | **Ensemble corrects both!** S2S hallucinated; Transformer had wrong inflection; Ensemble outputs 100% exact match. |
| **28** | ဘယ် လို ပေး ရ မ လဲ | `𓊪𓐍𓏏 𓏭𓄿𓎛 𓆑 𓄡𓄿𓂧` <br> *(How can I pay)* | `𓏏𓊪𓄿𓈎 𓏮𓀀𓎡𓂋𓇌 𓆑 𓇌𓐍` <br> *(Gibberish breakdown)* | `𓊪𓐍𓏏 𓏏𓄿𓈙 𓆑𓈎 𓄡𓄿𓂧` <br> *(Partially wrong: "how was it pay")* | `𓊪𓐍𓏏 𓏭𓄿𓎛 𓆑 𓄡𓄿𓂧` | **100% Exact Match.** Ensemble recovers modal auxiliary `can` (`𓏭𓄿𓎛`) where individual models failed. |
| **30** | Tom ကို မေး ခဲ့ တယ် ။ | `𓆑 𓄿𓈙𓈖𓂝𓇌 𓈎𓐍𓉔` <br> *(I asked Tom)* | `𓈎𓊪𓂝𓂧 𓄿𓈙𓈖𓂝𓇌 𓈎𓐍𓉔` <br> *(Wrong pronoun: "They asked Tom")* | `𓆑 𓊪𓄿𓎼𓂝 𓄿𓈙𓈖𓂝𓇌 𓈎𓐍𓉔` <br> *(Added aspect: "I have asked Tom")* | `𓆑 𓄿𓈙𓈖𓂝𓇌 𓈎𓐍𓉔` | **100% Exact Match.** Ensemble correctly selects first-person past tense without superfluous auxiliary verbs. |

---

### 6.2 Direction 2: Hieroglyphs → Myanmar

| # | Source Hieroglyphs (Cipher Text) | Deciphered English & Gold (Myanmar) | Seq2Seq-1 (Bi-LSTM) | Transformer-1 | Quad Ensemble (All 4) | Analysis & Resolution |
|---|---|---|---|---|---|---|
| **17** | `𓈙𓊪𓂝 𓈎𓋴𓆑𓂝𓇌` | *She tried* <br> `သူမ ကြိုးစားခဲ့တယ်။` | `သူမငိုခဲ့တယ်။` <br> *(She cried)* | `သူမကပင်ပန်းနေခဲ့တယ်။` <br> *(She was tired)* | `သူမကြိုးစားခဲ့တယ်။` <br> *(She tried)* | **Superb Ensemble Correction.** S2S confused the verb semantic; Transformer made a phonetic error ("tired" vs "tried"); Ensemble probability peak outputs the exact correct verb `ကြိုးစားခဲ့တယ်`! |
| **21** | `𓈎𓊪𓆑𓈙 𓆑𓈙 𓊪𓎡𓃀𓂝` | *This is huge* <br> `ဒါက ကြီးမားပါတယ်။` | `ဒါကခက်ခဲပါတယ်။` <br> *(This is hard)* | `ဒါကစစ်မှန်ပါတယ်။` <br> *(This is genuine)* | `ဒါကကြီးမားပါတယ်။` <br> *(This is huge)* | **100% Exact Match.** S2S and Transformer both substituted incorrect adjectives; Ensemble combines distributions to recover `ကြီးမား` (huge). |
| **32** | `𓈎𓊪𓆑𓈙 𓆑𓈙 𓂋𓐍𓎼𓂝` | *This is love* <br> `ဒါက အချစ်ပါ။` | `ဒါကဘဝပါ။` <br> *(This is life)* | `ဒါကအချစ်စရာပါ။` <br> *(This is lovely)* | `ဒါကအချစ်ပါ။` <br> *(This is love)* | **100% Exact Match.** Transformer hallucinated adjectival suffix `စရာ` (lovely); Ensemble corrected to root noun `အချစ်` (love). |
| **41** | `𓆑𓈎 𓏏𓄿𓈙𓎛𓈎 𓂋𓎡𓏭𓈖` | *It wasn't luck* <br> `ကံမကောင်းခဲ့ဘူး။` | `အနက်ရောင်မဟုတ်ဘူး။` <br> *(It wasn't black)* | `ကံမကောင်းခဲ့ဘူး။` <br> *(It wasn't luck)* | `ကံမကောင်းခဲ့ဘူး။` <br> *(It wasn't luck)* | S2S had catastrophic phonetic drift ("luck" vs "black"); Transformer and Ensemble preserved the exact meaning. |
| **49** | `𓏏𓊪𓐍 𓈎𓐍𓂋𓇌 𓂨𓀀𓎡` | *Who told you* <br> `ဘယ်သူ ပြောပြတာလဲ` | `ဘယ်သူ့ကိုပြောတာလဲ` <br> *(Whom did you tell)* | `ဘယ်သူပြောတာလဲ` <br> *(Who said)* | `ဘယ်သူပြောပြတာလဲ` <br> *(Who told you)* | **100% Exact Match.** S2S inverted subject/object marker (`ဘယ်သူ့ကို`); Ensemble restored the compound communicative verb `ပြောပြ` (told). |

---

## 7. Error Analysis & Linguistic Taxonomy

An audit of hypothesis outputs across all models reveals 5 primary error patterns:

```mermaid
flowchart LR
    ERR["Translation Errors"] --> E1["1. Orthographic Cipher Confusion"]
    ERR --> E2["2. Lexical & Synonym Drift"]
    ERR --> E3["3. SOV vs SVO Syntactic Alignment"]
    ERR --> E4["4. Sociolinguistic Gender Pronoun Ambiguity"]
    ERR --> E5["5. Recurrent Truncation vs Particle Hallucination"]
```

1. **Orthographic Cipher Confusion (Phonetic Drift)**:
   - Because glyphs correspond to English letters, letter transpositions create confusion (e.g., Line 17 `she tried` vs `she was tired`).
2. **Lexical & Synonym Substitution**:
   - The model frequently outputs fluent, valid synonyms that do not match the exact gold n-grams (e.g., `ခရီးကောင်းပါ` translated to `have a safe trip` instead of `have a nice trip`).
3. **SOV vs. SVO Syntactic Alignment**:
   - Myanmar places case markers after nouns (`က` = Subject, `ကို` = Object). In Seq2Seq, the recurrent encoder occasionally inverted argument roles. The Transformer's cross-attention resolved this by directly attending to the case markers.
4. **Sociolinguistic Pronoun Disambiguation**:
   - English cipher has only the neutral pronoun `I` (`𓆑`). In Myanmar, the model must infer between male `ကျွန်တော်` and female `ကျွန်မ`. Mismatches in gender choice are penalized by BLEU despite being grammatically correct.
5. **Under-Generation (Truncation) vs. Over-Generation (Particles)**:
   - Seq2Seq decoders suffer from an early `</s>` (EOS) probability bias on sentences longer than 5 words.
   - Transformers occasionally hallucinated polite particles (`ပါ`, `စရာ`) in Myanmar, causing minor 1-gram precision penalties.

---

## 8. Practical Discussion: What Worked, What Failed & Why

### 1. What Worked
- **Syllable Breaking (`sylbreak`)**: Slashed Myanmar test OOV from 47.3% to 2.30%. Without this, NMT simply fails on Myanmar text.
- **Character Hieroglyphs with `_` Boundary**: Reduced target vocabulary to 37 tokens and eliminated OOV completely (0.00%), driving peak exact sentence matches to 21.6%.
- **Transformer on Dual Tesla T4**: Completed training in 3.6 to 5.5 minutes (~6× faster than S2S) with +10 to +14 higher BLEU.
- **Heterogeneous Ensembling (`seq2seq + transformer`)**: Delivered a huge +3.7 to +4.2 BLEU boost by combining the complementary strengths of recurrence and self-attention.
- **Calibrated Validation Frequency (`--valid-freq 500 --early-stopping 4`)**: Prevented the 5-hour S2S training stalls seen in earlier course reference notebooks.

### 2. What Failed (and How We Fixed It)
- **Word-Level Hieroglyphics (Phase 1)**: Capped model vocabulary at 2,858 words with 82 unseen test words (14.5% OOV). Fixed in Phase 2 by decomposing into character tokens with `_` boundaries.
- **Homogeneous Ensembling (`tr1 + tr2` or `seq1 + seq2`)**: Yielded only small gains (+0.4 to +1.1 BLEU) because two identical architectures make correlated errors. Heterogeneous ensembling resolved this.
- **Early Seq2Seq S2S Stalling**: In previous reference notebooks, S2S models trained for 5.5 hours because `--valid-freq 5000` waited 2,600 epochs after plateauing. Changing to `--valid-freq 500` allowed early stopping to trigger cleanly at step ~2,500 (~28–31 minutes).

---

## 9. Repository Structure & Submission Manifest

The repository is organized for clean, self-contained reproducibility:

```
assignment-6/
├── thein_kyaw_lwin.assignment-6-report.md   # Complete Source of Truth technical report
├── myhi_data/                               # Original raw corpus (train, valid, test)
│   ├── train.my, train.hi
│   ├── valid.my, valid.hi
│   └── test.my, test.hi
├── myhi-par/                                # Phase 1 dataset (Word HI + Syl MY)
├── myhi-char-par/                           # Phase 2 dataset (Char HI with '_' boundary + Syl MY, 0% OOV)
├── scripts/
│   ├── preprocess_myhi.py                   # Phase 1 sylbreak preprocessing script
│   ├── preprocess_myhi_char.py              # Phase 2 char-level preprocessing script
│   └── aggregate_results.py                 # Standalone evaluation & table aggregator
├── marian-my2hi/                            # Phase 1 Kernel: Myanmar -> Hiero (Word)
│   ├── train_my2hi.py
│   └── kernel-metadata.json
├── marian-hi2my/                            # Phase 1 Kernel: Hiero -> Myanmar (Word)
│   ├── train_hi2my.py
│   └── kernel-metadata.json
├── marian-my2hi-char/                       # Phase 2 Kernel: Myanmar -> Hiero (Char + 4 Ensembles)
│   ├── train_my2hi_char.py
│   └── kernel-metadata.json
├── marian-hi2my-char/                       # Phase 2 Kernel: Hiero -> Myanmar (Char + 4 Ensembles)
│   ├── train_hi2my_char.py
│   └── kernel-metadata.json
└── results/                                 # Downloaded evaluation artifacts (logs, configs & hypotheses)
    ├── marian-my2hi/
    ├── marian-hi2my/
    ├── marian-my2hi-char/
    └── marian-hi2my-char/
```

---

## 10. Reproduction Guide

### Step 1: Preprocessing Datasets Locally
```bash
python3 scripts/preprocess_myhi.py
python3 scripts/preprocess_myhi_char.py
```

### Step 2: Running Training Kernels on Kaggle
```bash
# Push Phase 2 kernels (Dual Tesla T4)
kaggle kernels push -p marian-my2hi-char
kaggle kernels push -p marian-hi2my-char

# Monitor execution status
kaggle kernels status theinkyawlwin/marian-my2hi-char
kaggle kernels status theinkyawlwin/marian-hi2my-char
```

### Step 3: Downloading Outputs Locally (Excluding Model Binaries)
> [!IMPORTANT]
> Adding `--file-pattern ".*\.(log|txt|yml)$"` is crucial: it downloads all decoded test hypotheses, evaluation summaries, training logs, and model configurations while excluding heavy `.npz` binary checkpoints (~1GB each).

```bash
# Download Myanmar -> Hieroglyphs evaluation artifacts
kaggle kernels output theinkyawlwin/marian-my2hi-char \
  --file-pattern ".*\.(log|txt|yml)$" \
  -p results/marian-my2hi-char

# Download Hieroglyphs -> Myanmar evaluation artifacts
kaggle kernels output theinkyawlwin/marian-hi2my-char \
  --file-pattern ".*\.(log|txt|yml)$" \
  -p results/marian-hi2my-char
```

### Step 4: Aggregating & Verifying Results Locally
```bash
python3 scripts/aggregate_results.py
```

