"""
train_my2hi_char.py
===================
Assignment 6 (Expanded Experiment Suite): Myanmar -> Character-Level Hieroglyphs
Author: Thein Kyaw Lwin

Representations:
  - Source: Myanmar Syllable-level (sylbreak regex, 1,079 vocab)
  - Target: Hieroglyphs Character-level with '_' word boundaries (37 vocab, 0% OOV)

Models Trained in Single Kaggle Dual-T4 Session:
  1. Seq2Seq-1 (Bi-LSTM, seed 1111)
  2. Seq2Seq-2 (Bi-LSTM, seed 2222)
  3. Transformer-1 (Self-Attention Base, seed 1111)
  4. Transformer-2 (Self-Attention Tuned Warmup, seed 2222)

Ensembles Evaluated (Marian multi-model decoding):
  - Ensemble A (tr1 + tr2): Transformer-1 + Transformer-2
  - Ensemble B (seq1 + seq2): Seq2Seq-1 + Seq2Seq-2
  - Ensemble C (seq2seq + transformer): Seq2Seq-1 + Transformer-1
  - Ensemble D (quad): All 4 models combined (0.25 each)

Datasets:
  - theinkyawlwin/marian-nmt
  - theinkyawlwin/myhi-char-par
"""

import os
import sys
import stat
import time
import shutil
import math
import subprocess
from pathlib import Path
from collections import Counter


def run(cmd: str, **kwargs):
    print(f"\n>>> {cmd}\n{'=' * 75}")
    subprocess.run(cmd, shell=True, check=True,
                   stdout=sys.stdout, stderr=sys.stderr, **kwargs)


def section(title: str):
    print(f"\n{'#' * 75}")
    print(f"# {title}")
    print(f"{'#' * 75}\n")


def find_file_recursive(root_candidates: list, filename: str) -> str:
    for root_dir in root_candidates:
        if os.path.exists(root_dir):
            for current_root, _, files in os.walk(root_dir):
                if filename in files:
                    full_path = os.path.join(current_root, filename)
                    print(f"[ok] Found {filename}: {full_path}")
                    return full_path
    raise FileNotFoundError(
        f"[ERROR] Could not find '{filename}' recursively under: {root_candidates}"
    )


def compute_corpus_bleu(hypotheses, references, max_n=4, smooth=True):
    clipped_counts = Counter()
    total_counts = Counter()
    hyp_len = 0
    ref_len = 0

    for hyp, ref in zip(hypotheses, references):
        hyp_toks = hyp.strip().split()
        ref_toks = ref.strip().split()
        hyp_len += len(hyp_toks)
        ref_len += len(ref_toks)

        for n in range(1, max_n + 1):
            hyp_ngrams = [tuple(hyp_toks[i:i+n]) for i in range(len(hyp_toks)-n+1)]
            ref_ngrams = [tuple(ref_toks[i:i+n]) for i in range(len(ref_toks)-n+1)]
            ref_counts = Counter(ref_ngrams)
            for ng, cnt in Counter(hyp_ngrams).items():
                clipped_counts[n] += min(cnt, ref_counts.get(ng, 0))
                total_counts[n] += cnt

    precisions = []
    for n in range(1, max_n + 1):
        if total_counts[n] == 0:
            p = 1e-7
        elif clipped_counts[n] == 0:
            p = (1.0 / (2 ** n * total_counts[n])) if smooth else 1e-7
        else:
            p = clipped_counts[n] / total_counts[n]
        precisions.append(p)

    bp = 1.0 if hyp_len >= ref_len else math.exp(1 - ref_len / max(1, hyp_len))
    log_sum = sum(math.log(p) for p in precisions) / max_n
    bleu = bp * math.exp(log_sum) * 100
    return bleu, precisions, bp


def char_tokens_to_hi(text: str) -> str:
    """Lossless reconstruction of word-level Hieroglyphs from character tokens."""
    parts = text.strip().split("_")
    return " ".join("".join(p.split()) for p in parts)


def get_best_checkpoint(model_dir: str, base_name: str = "model.npz") -> str:
    target = os.path.join(model_dir, base_name)
    candidates = [
        f"{target}.best-bleu.npz",
        f"{target}.best-cross-entropy.npz",
        target,
    ]
    for c in candidates:
        if os.path.exists(c):
            print(f"[ok] Selected checkpoint: {c}")
            return c
    raise FileNotFoundError(f"[ERROR] No model checkpoint found in {model_dir}")


# ---------------------------------------------------------------------------
# Setup Paths & Auto-Discovery
# ---------------------------------------------------------------------------

SRC = "my"   # Myanmar syllables
TGT = "hi"   # Hieroglyphs characters

WORKING_DIR = "/kaggle/working"
LOCAL_BINS  = os.path.join(WORKING_DIR, "bins")
PREPROC_DIR = os.path.join(WORKING_DIR, "preprocessing")
VOCAB_DIR   = os.path.join(WORKING_DIR, "vocab")

S2S1_DIR    = os.path.join(WORKING_DIR, f"model.s2s_1.{SRC}2{TGT}")
S2S2_DIR    = os.path.join(WORKING_DIR, f"model.s2s_2.{SRC}2{TGT}")
TR1_DIR     = os.path.join(WORKING_DIR, f"model.tr_1.{SRC}2{TGT}")
TR2_DIR     = os.path.join(WORKING_DIR, f"model.tr_2.{SRC}2{TGT}")

for d in [LOCAL_BINS, PREPROC_DIR, VOCAB_DIR, S2S1_DIR, S2S2_DIR, TR1_DIR, TR2_DIR]:
    os.makedirs(d, exist_ok=True)

MARIAN_SEARCH_ROOTS = [
    "/kaggle/input/marian-nmt",
    "/kaggle/input/datasets/theinkyawlwin/marian-nmt",
]

DATA_SEARCH_ROOTS = [
    "/kaggle/input/myhi-char-par",
    "/kaggle/input/datasets/theinkyawlwin/myhi-char-par",
]

total_start_time = time.time()


# ---------------------------------------------------------------------------
# Step 1: Install Executable Marian Binaries
# ---------------------------------------------------------------------------

section("Step 1: Discover & Setup Executable Marian Binaries")

for bin_name in ["marian", "marian-vocab", "marian-decoder"]:
    found_bin = find_file_recursive(MARIAN_SEARCH_ROOTS, bin_name)
    local_target = os.path.join(LOCAL_BINS, bin_name)
    shutil.copy2(found_bin, local_target)
    os.chmod(local_target, 0o755)
    print(f"[ok] Installed: {local_target}")

MARIAN         = os.path.join(LOCAL_BINS, "marian")
MARIAN_VOCAB   = os.path.join(LOCAL_BINS, "marian-vocab")
MARIAN_DECODER = os.path.join(LOCAL_BINS, "marian-decoder")

run(f"{MARIAN} --version")


# ---------------------------------------------------------------------------
# Step 2: Locate Parallel Data & Build Shared Vocabularies
# ---------------------------------------------------------------------------

section("Step 2: Locate Parallel Data & Build Shared Vocabularies")

train_src = find_file_recursive(DATA_SEARCH_ROOTS, f"train.{SRC}")
train_tgt = find_file_recursive(DATA_SEARCH_ROOTS, f"train.{TGT}")
dev_src   = find_file_recursive(DATA_SEARCH_ROOTS, f"dev.{SRC}")
dev_tgt   = find_file_recursive(DATA_SEARCH_ROOTS, f"dev.{TGT}")
test_src  = find_file_recursive(DATA_SEARCH_ROOTS, f"test.{SRC}")
test_tgt  = find_file_recursive(DATA_SEARCH_ROOTS, f"test.{TGT}")

try:
    test_raw_hi = find_file_recursive(DATA_SEARCH_ROOTS, "test.hi.raw")
except Exception:
    test_raw_hi = None

print(f"\nCorpus line verification:")
run(f"wc -l {train_src} {train_tgt} {dev_src} {dev_tgt} {test_src} {test_tgt}")

# Concatenate train + dev
merged_src = os.path.join(PREPROC_DIR, f"train-dev.{SRC}")
merged_tgt = os.path.join(PREPROC_DIR, f"train-dev.{TGT}")
run(f"cat {train_src} {dev_src} > {merged_src}")
run(f"cat {train_tgt} {dev_tgt} > {merged_tgt}")

vocab_src = os.path.join(VOCAB_DIR, f"vocab.{SRC}.yml")
vocab_tgt = os.path.join(VOCAB_DIR, f"vocab.{TGT}.yml")

run(f"{MARIAN_VOCAB} < {merged_src} > {vocab_src}")
run(f"{MARIAN_VOCAB} < {merged_tgt} > {vocab_tgt}")

print(f"\nVocabulary Summary:")
run(f"wc -l {vocab_src} {vocab_tgt}")


# ---------------------------------------------------------------------------
# Helper Training & Decoding Functions
# ---------------------------------------------------------------------------

def train_s2s(model_dir, seed):
    cfg = os.path.join(model_dir, "config.yml")
    npz = os.path.join(model_dir, "model.npz")
    log = os.path.join(model_dir, "train.log")
    vlog = os.path.join(model_dir, "valid.log")
    vout = os.path.join(model_dir, "valid.output")

    args = " ".join([
        f"--model {npz}",
        f"--type s2s",
        f"--train-sets {train_src} {train_tgt}",
        f"--max-length 150",
        f"--vocabs {vocab_src} {vocab_tgt}",
        f"--workspace 5000",
        f"--enc-depth 2 --enc-type alternating --enc-cell lstm --enc-cell-depth 2",
        f"--dec-depth 2 --dec-cell lstm --dec-cell-base-depth 2 --dec-cell-high-depth 2",
        f"--tied-embeddings --layer-normalization --skip",
        f"--mini-batch-fit",
        f"--valid-sets {dev_src} {dev_tgt}",
        f"--valid-mini-batch 32",
        f"--valid-metrics cross-entropy perplexity bleu",
        f"--valid-translation-output {vout} --quiet-translation",
        f"--valid-freq 500 --save-freq 500 --disp-freq 100",
        f"--dropout-rnn 0.3 --dropout-src 0.3 --exponential-smoothing",
        f"--learn-rate 0.0003 --lr-decay-inv-sqrt 4000 --lr-report",
        f"--label-smoothing 0.1 --clip-norm 5",
        f"--beam-size 6 --normalize 0.6",
        f"--early-stopping 4",
        f"--after-batches 6000",
        f"--log {log} --valid-log {vlog}",
        f"--devices 0 1 --sync-sgd --seed {seed}",
    ])
    run(f"{MARIAN} {args} --dump-config > {cfg}")
    _t0 = time.time()
    run(f"{MARIAN} -c {cfg} 2>&1 | tee {model_dir}/train.run.log")
    return (time.time() - _t0) / 60


def train_trans(model_dir, seed, warmup=0, dropout=0.2):
    cfg = os.path.join(model_dir, "config.yml")
    npz = os.path.join(model_dir, "model.npz")
    log = os.path.join(model_dir, "train.log")
    vlog = os.path.join(model_dir, "valid.log")
    vout = os.path.join(model_dir, "valid.output")

    args = " ".join([
        f"--model {npz}",
        f"--type transformer",
        f"--train-sets {train_src} {train_tgt}",
        f"--max-length 150",
        f"--vocabs {vocab_src} {vocab_tgt}",
        f"--mini-batch-fit -w 1000 --maxi-batch 100",
        f"--early-stopping 4",
        f"--valid-freq 500 --save-freq 500 --disp-freq 100",
        f"--valid-metrics cross-entropy perplexity bleu",
        f"--valid-sets {dev_src} {dev_tgt}",
        f"--valid-translation-output {vout} --quiet-translation",
        f"--valid-mini-batch 64",
        f"--beam-size 6 --normalize 0.6",
        f"--log {log} --valid-log {vlog}",
        f"--enc-depth 2 --dec-depth 2",
        f"--transformer-heads 8",
        f"--transformer-postprocess-emb d",
        f"--transformer-postprocess dan",
        f"--transformer-dropout {dropout} --label-smoothing 0.1",
        f"--learn-rate 0.0003 --lr-warmup {warmup} --lr-decay-inv-sqrt 4000 --lr-report",
        f"--clip-norm 5 --tied-embeddings",
        f"--after-batches 6000",
        f"--devices 0 1 --sync-sgd --seed {seed}",
        f"--exponential-smoothing",
    ])
    run(f"{MARIAN} {args} --dump-config > {cfg}")
    _t0 = time.time()
    run(f"{MARIAN} -c {cfg} 2>&1 | tee {model_dir}/train.run.log")
    return (time.time() - _t0) / 60


def decode_model(model_checkpoints, weights, hyp_file):
    ckpt_args = " ".join(model_checkpoints)
    weight_args = f"--weights {' '.join(str(w) for w in weights)}" if len(model_checkpoints) > 1 else ""
    cmd = f"{MARIAN_DECODER} -m {ckpt_args} {weight_args} -v {vocab_src} {vocab_tgt} --devices 0 --beam-size 6 --normalize 0.6 < {test_src} > {hyp_file}"
    run(cmd)


# ---------------------------------------------------------------------------
# Training All 4 Models
# ---------------------------------------------------------------------------

section("Training Model 1: Seq2Seq-1 (Seed 1111)")
time_s2s1 = train_s2s(S2S1_DIR, seed=1111)
ckpt_s2s1 = get_best_checkpoint(S2S1_DIR)

section("Training Model 2: Seq2Seq-2 (Seed 2222)")
time_s2s2 = train_s2s(S2S2_DIR, seed=2222)
ckpt_s2s2 = get_best_checkpoint(S2S2_DIR)

section("Training Model 3: Transformer-1 (Base, Seed 1111)")
time_tr1 = train_trans(TR1_DIR, seed=1111, warmup=0, dropout=0.2)
ckpt_tr1 = get_best_checkpoint(TR1_DIR)

section("Training Model 4: Transformer-2 (Tuned Warmup 2000, Seed 2222)")
time_tr2 = train_trans(TR2_DIR, seed=2222, warmup=2000, dropout=0.2)
ckpt_tr2 = get_best_checkpoint(TR2_DIR)


# ---------------------------------------------------------------------------
# Decoding Individual Models & Ensembles
# ---------------------------------------------------------------------------

section("Decoding Individual Models & Ensemble Variations")

eval_runs = [
    # Individual models
    ("Seq2Seq-1", [ckpt_s2s1], [1.0], time_s2s1),
    ("Seq2Seq-2", [ckpt_s2s2], [1.0], time_s2s2),
    ("Transformer-1", [ckpt_tr1], [1.0], time_tr1),
    ("Transformer-2", [ckpt_tr2], [1.0], time_tr2),
    # Ensembles
    ("Ensemble: tr1 + tr2", [ckpt_tr1, ckpt_tr2], [0.5, 0.5], None),
    ("Ensemble: seq1 + seq2", [ckpt_s2s1, ckpt_s2s2], [0.5, 0.5], None),
    ("Ensemble: seq2seq + transformer", [ckpt_s2s1, ckpt_tr2], [0.5, 0.5], None),
    ("Ensemble: All 4 Models", [ckpt_s2s1, ckpt_s2s2, ckpt_tr1, ckpt_tr2], [0.25, 0.25, 0.25, 0.25], None),
]

with open(test_tgt) as f:
    gold_char_refs = [l.strip() for l in f]

with open(test_raw_hi) as f:
    gold_word_refs = [l.strip() for l in f]

results_table = []

for name, ckpts, weights, t_train in eval_runs:
    slug = name.lower().replace(":", "").replace("+", "_").replace(" ", "_")
    hyp_char = os.path.join(WORKING_DIR, f"hyp.char.{slug}.txt")
    hyp_word = os.path.join(WORKING_DIR, f"hyp.word.{slug}.txt")

    print(f"\nDecoding {name} ...")
    decode_model(ckpts, weights, hyp_char)

    with open(hyp_char) as f:
        char_lines = [l.strip() for l in f]

    word_lines = [char_tokens_to_hi(l) for l in char_lines]
    with open(hyp_word, "w") as f_w:
        for wl in word_lines:
            f_w.write(wl + "\n")

    char_bleu, _, bp_c = compute_corpus_bleu(char_lines, gold_char_refs)
    word_bleu, _, bp_w = compute_corpus_bleu(word_lines, gold_word_refs)
    exact_matches = sum(1 for hw, gw in zip(word_lines, gold_word_refs) if hw == gw)

    results_table.append({
        "name": name,
        "char_bleu": char_bleu,
        "word_bleu": word_bleu,
        "bp_word": bp_w,
        "exact_matches": exact_matches,
        "train_time": t_train,
    })


# ---------------------------------------------------------------------------
# Comparative Reporting
# ---------------------------------------------------------------------------

section("Comparative Summary: Myanmar -> Hieroglyphs (Character-Level Representation)")

total_duration = (time.time() - total_start_time) / 60

print("\n" + "=" * 90)
print(f"EXPANDED RESULTS: MYANMAR (Syllables) -> HIEROGLYPHS (Characters)")
print("=" * 90)
print(f"{'Model / Ensemble Configuration':<34} | {'Char BLEU':>10} | {'Word BLEU':>10} | {'Exact Matches':>14} | {'Train Time':>10}")
print("-" * 90)
for r in results_table:
    time_str = f"{r['train_time']:.2f} min" if r['train_time'] is not None else "—"
    em_str = f"{r['exact_matches']}/500 ({r['exact_matches']/5:.1f}%)"
    print(f"{r['name']:<34} | {r['char_bleu']:>10.4f} | {r['word_bleu']:>10.4f} | {em_str:>14} | {time_str:>10}")
print("=" * 90)
print(f"Total Pipeline Runtime: {total_duration:.2f} minutes")

# Save summary report
report_path = os.path.join(WORKING_DIR, "summary_report_my2hi_char.txt")
with open(report_path, "w", encoding="utf-8") as f_rep:
    f_rep.write("=== EXPANDED EVALUATION SUMMARY: MY -> HI (CHAR) ===\n")
    for r in results_table:
        f_rep.write(f"{r['name']} | Char BLEU: {r['char_bleu']:.4f} | Word BLEU: {r['word_bleu']:.4f} | Exact: {r['exact_matches']}/500\n")
    f_rep.write(f"Total Runtime: {total_duration:.2f}m\n")

print("\n--- Side-by-Side Word Predictions (First 15 lines of Best Ensemble) ---")
best_hyp_word = os.path.join(WORKING_DIR, "hyp.word.ensemble_tr1__tr2.txt")
if os.path.exists(best_hyp_word):
    run(f"paste {test_src} {best_hyp_word} {test_raw_hi} | head -n 15")

print(f"\n[ALL DONE] Pipeline completed successfully in {total_duration:.2f} minutes!")

