"""
train_hi2my.py
==============
Assignment 6: Egyptian Hieroglyphic -> Myanmar Neural Machine Translation
Author: Thein Kyaw Lwin

Pipeline executed in a single Kaggle session on 2x Tesla T4 GPUs:
  Stage 1: Train Seq2Seq Baseline (Bi-LSTM Encoder-Decoder with Attention)
  Stage 2: Train Transformer Baseline (Multi-Head Self-Attention + Warmup)
  Stage 3: Ensemble Decoding (Combining Seq2Seq + Transformer)
  Stage 4: Automated BLEU Evaluation, Detokenization & Comparative Analysis

Datasets:
  - theinkyawlwin/marian-nmt   (Compiled Marian v1.12 binaries)
  - theinkyawlwin/myhi-par     (Preprocessed parallel dataset)
"""

import os
import sys
import stat
import time
import shutil
import math
import subprocess
from pathlib import Path
from collections import Counter


# ---------------------------------------------------------------------------
# Helpers & Utilities
# ---------------------------------------------------------------------------

def run(cmd: str, **kwargs):
    """Run shell command, stream stdout/stderr, raise on failure."""
    print(f"\n>>> {cmd}\n{'=' * 75}")
    subprocess.run(cmd, shell=True, check=True,
                   stdout=sys.stdout, stderr=sys.stderr, **kwargs)


def section(title: str):
    """Visually distinct section separator."""
    print(f"\n{'#' * 75}")
    print(f"# {title}")
    print(f"{'#' * 75}\n")


def find_file_recursive(root_candidates: list, filename: str) -> str:
    """Search recursively for a filename under candidate directories."""
    for root_dir in root_candidates:
        if os.path.exists(root_dir):
            for current_root, _, files in os.walk(root_dir):
                if filename in files:
                    full_path = os.path.join(current_root, filename)
                    print(f"[ok] Found {filename}: {full_path}")
                    return full_path
    raise FileNotFoundError(
        f"[ERROR] Could not find '{filename}' recursively under: {root_candidates}"
    )


def compute_corpus_bleu(hypotheses, references, max_n=4, smooth=True):
    """Compute corpus-level BLEU score with Chen & Cherry smoothing."""
    clipped_counts = Counter()
    total_counts = Counter()
    hyp_len = 0
    ref_len = 0

    for hyp, ref in zip(hypotheses, references):
        hyp_toks = hyp.strip().split()
        ref_toks = ref.strip().split()
        hyp_len += len(hyp_toks)
        ref_len += len(ref_toks)

        for n in range(1, max_n + 1):
            hyp_ngrams = [tuple(hyp_toks[i:i+n]) for i in range(len(hyp_toks)-n+1)]
            ref_ngrams = [tuple(ref_toks[i:i+n]) for i in range(len(ref_toks)-n+1)]
            ref_counts = Counter(ref_ngrams)
            for ng, cnt in Counter(hyp_ngrams).items():
                clipped_counts[n] += min(cnt, ref_counts.get(ng, 0))
                total_counts[n] += cnt

    precisions = []
    for n in range(1, max_n + 1):
        if total_counts[n] == 0:
            p = 1e-7
        elif clipped_counts[n] == 0:
            p = (1.0 / (2 ** n * total_counts[n])) if smooth else 1e-7
        else:
            p = clipped_counts[n] / total_counts[n]
        precisions.append(p)

    bp = 1.0 if hyp_len >= ref_len else math.exp(1 - ref_len / max(1, hyp_len))
    log_sum = sum(math.log(p) for p in precisions) / max_n
    bleu = bp * math.exp(log_sum) * 100
    return bleu, precisions, bp


def get_best_checkpoint(model_dir: str, base_name: str = "model.npz") -> str:
    """Return best checkpoint by validation BLEU or fallback to base model."""
    target = os.path.join(model_dir, base_name)
    candidates = [
        f"{target}.best-bleu.npz",
        f"{target}.best-cross-entropy.npz",
        target,
    ]
    for c in candidates:
        if os.path.exists(c):
            print(f"[ok] Selected checkpoint: {c}")
            return c
    raise FileNotFoundError(f"[ERROR] No model checkpoint found in {model_dir}")


# ---------------------------------------------------------------------------
# Setup Paths & Auto-Discovery
# ---------------------------------------------------------------------------

SRC = "hi"   # Egyptian Hieroglyphs
TGT = "my"   # Myanmar syllables

WORKING_DIR = "/kaggle/working"
LOCAL_BINS  = os.path.join(WORKING_DIR, "bins")
PREPROC_DIR = os.path.join(WORKING_DIR, "preprocessing")
VOCAB_DIR   = os.path.join(WORKING_DIR, "vocab")
S2S_DIR     = os.path.join(WORKING_DIR, f"model.s2s.{SRC}2{TGT}")
TRANS_DIR   = os.path.join(WORKING_DIR, f"model.transformer.{SRC}2{TGT}")

os.makedirs(LOCAL_BINS, exist_ok=True)
os.makedirs(PREPROC_DIR, exist_ok=True)
os.makedirs(VOCAB_DIR, exist_ok=True)
os.makedirs(S2S_DIR, exist_ok=True)
os.makedirs(TRANS_DIR, exist_ok=True)

MARIAN_SEARCH_ROOTS = [
    "/kaggle/input/marian-nmt",
    "/kaggle/input/datasets/theinkyawlwin/marian-nmt",
]

DATA_SEARCH_ROOTS = [
    "/kaggle/input/myhi-par",
    "/kaggle/input/datasets/theinkyawlwin/myhi-par",
]

total_start_time = time.time()


# ---------------------------------------------------------------------------
# Step 1: Install Executable Marian Binaries
# ---------------------------------------------------------------------------

section("Step 1: Discover & Setup Executable Marian Binaries")

for bin_name in ["marian", "marian-vocab", "marian-decoder"]:
    found_bin = find_file_recursive(MARIAN_SEARCH_ROOTS, bin_name)
    local_target = os.path.join(LOCAL_BINS, bin_name)
    shutil.copy2(found_bin, local_target)
    os.chmod(local_target, 0o755)
    print(f"[ok] Installed: {local_target}")

MARIAN         = os.path.join(LOCAL_BINS, "marian")
MARIAN_VOCAB   = os.path.join(LOCAL_BINS, "marian-vocab")
MARIAN_DECODER = os.path.join(LOCAL_BINS, "marian-decoder")

run(f"{MARIAN} --version")


# ---------------------------------------------------------------------------
# Step 2: Locate Parallel Data & Build Shared Vocabularies
# ---------------------------------------------------------------------------

section("Step 2: Locate Parallel Data & Build Shared Vocabularies")

train_src = find_file_recursive(DATA_SEARCH_ROOTS, f"train.{SRC}")
train_tgt = find_file_recursive(DATA_SEARCH_ROOTS, f"train.{TGT}")
dev_src   = find_file_recursive(DATA_SEARCH_ROOTS, f"dev.{SRC}")
dev_tgt   = find_file_recursive(DATA_SEARCH_ROOTS, f"dev.{TGT}")
test_src  = find_file_recursive(DATA_SEARCH_ROOTS, f"test.{SRC}")
test_tgt  = find_file_recursive(DATA_SEARCH_ROOTS, f"test.{TGT}")

try:
    test_raw_my = find_file_recursive(DATA_SEARCH_ROOTS, "test.my.raw")
except Exception:
    test_raw_my = None

print(f"\nCorpus line verification:")
run(f"wc -l {train_src} {train_tgt} {dev_src} {dev_tgt} {test_src} {test_tgt}")

# Concatenate train + dev for comprehensive vocabulary coverage
merged_src = os.path.join(PREPROC_DIR, f"train-dev.{SRC}")
merged_tgt = os.path.join(PREPROC_DIR, f"train-dev.{TGT}")
run(f"cat {train_src} {dev_src} > {merged_src}")
run(f"cat {train_tgt} {dev_tgt} > {merged_tgt}")

vocab_src = os.path.join(VOCAB_DIR, f"vocab.{SRC}.yml")
vocab_tgt = os.path.join(VOCAB_DIR, f"vocab.{TGT}.yml")

run(f"{MARIAN_VOCAB} < {merged_src} > {vocab_src}")
run(f"{MARIAN_VOCAB} < {merged_tgt} > {vocab_tgt}")

print(f"\nVocabulary Summary:")
run(f"wc -l {vocab_src} {vocab_tgt}")


# ---------------------------------------------------------------------------
# Stage 1: Train Seq2Seq Baseline
# ---------------------------------------------------------------------------

section("Stage 1: Train Seq2Seq Baseline (Bi-LSTM + Attention)")

s2s_cfg   = os.path.join(S2S_DIR, "config.yml")
s2s_npz   = os.path.join(S2S_DIR, "model.npz")
s2s_log   = os.path.join(S2S_DIR, "train.log")
s2s_vlog  = os.path.join(S2S_DIR, "valid.log")
s2s_vout  = os.path.join(S2S_DIR, "valid.output")

s2s_args = " ".join([
    f"--model {s2s_npz}",
    f"--type s2s",
    f"--train-sets {train_src} {train_tgt}",
    f"--max-length 150",
    f"--vocabs {vocab_src} {vocab_tgt}",
    f"--workspace 5000",
    f"--enc-depth 2 --enc-type alternating --enc-cell lstm --enc-cell-depth 2",
    f"--dec-depth 2 --dec-cell lstm --dec-cell-base-depth 2 --dec-cell-high-depth 2",
    f"--tied-embeddings --layer-normalization --skip",
    f"--mini-batch-fit",
    f"--valid-sets {dev_src} {dev_tgt}",
    f"--valid-mini-batch 32",
    f"--valid-metrics cross-entropy perplexity bleu",
    f"--valid-translation-output {s2s_vout} --quiet-translation",
    f"--valid-freq 1000 --save-freq 1000 --disp-freq 200",
    f"--dropout-rnn 0.3 --dropout-src 0.3 --exponential-smoothing",
    f"--learn-rate 0.0003 --lr-decay-inv-sqrt 8000 --lr-report",
    f"--label-smoothing 0.1 --clip-norm 5",
    f"--beam-size 6 --normalize 0.6",
    f"--early-stopping 5",
    f"--after-batches 12000",
    f"--log {s2s_log} --valid-log {s2s_vlog}",
    f"--devices 0 1 --sync-sgd --seed 1111",
])

run(f"{MARIAN} {s2s_args} --dump-config > {s2s_cfg}")
print("\n[info] Starting Seq2Seq training on Dual Tesla T4 GPUs...")
_t_s2s = time.time()
run(f"{MARIAN} -c {s2s_cfg} 2>&1 | tee {S2S_DIR}/train.s2s.run.log")
s2s_duration = (time.time() - _t_s2s) / 60
print(f"[info] Seq2Seq training completed in {s2s_duration:.2f} minutes.")

# Decode Test Set with Seq2Seq
ckpt_s2s = get_best_checkpoint(S2S_DIR)
hyp_s2s = os.path.join(WORKING_DIR, f"test.s2s.{SRC}2{TGT}.hyp.txt")
run(" ".join([
    MARIAN_DECODER,
    f"-m {ckpt_s2s}",
    f"-v {vocab_src} {vocab_tgt}",
    f"--devices 0",
    f"--beam-size 6 --normalize 0.6",
    f"< {test_src}",
    f"> {hyp_s2s}",
]))

with open(hyp_s2s) as f_h, open(test_tgt) as f_r:
    bleu_s2s, prec_s2s, bp_s2s = compute_corpus_bleu([l.strip() for l in f_h], [l.strip() for l in f_r])
print(f"[RESULT] Seq2Seq Test Syllable BLEU: {bleu_s2s:.4f} (BP={bp_s2s:.4f})")


# ---------------------------------------------------------------------------
# Stage 2: Train Transformer Baseline
# ---------------------------------------------------------------------------

section("Stage 2: Train Transformer Baseline (Self-Attention + Warmup)")

trans_cfg   = os.path.join(TRANS_DIR, "config.yml")
trans_npz   = os.path.join(TRANS_DIR, "model.npz")
trans_log   = os.path.join(TRANS_DIR, "train.log")
trans_vlog  = os.path.join(TRANS_DIR, "valid.log")
trans_vout  = os.path.join(TRANS_DIR, "valid.output")

trans_args = " ".join([
    f"--model {trans_npz}",
    f"--type transformer",
    f"--train-sets {train_src} {train_tgt}",
    f"--max-length 150",
    f"--vocabs {vocab_src} {vocab_tgt}",
    f"--mini-batch-fit -w 1000 --maxi-batch 100",
    f"--early-stopping 5",
    f"--valid-freq 1000 --save-freq 1000 --disp-freq 200",
    f"--valid-metrics cross-entropy perplexity bleu",
    f"--valid-sets {dev_src} {dev_tgt}",
    f"--valid-translation-output {trans_vout} --quiet-translation",
    f"--valid-mini-batch 64",
    f"--beam-size 6 --normalize 0.6",
    f"--log {trans_log} --valid-log {trans_vlog}",
    f"--enc-depth 2 --dec-depth 2",
    f"--transformer-heads 8",
    f"--transformer-postprocess-emb d",
    f"--transformer-postprocess dan",
    f"--transformer-dropout 0.2 --label-smoothing 0.1",
    f"--learn-rate 0.0003 --lr-warmup 2000 --lr-decay-inv-sqrt 8000 --lr-report",
    f"--clip-norm 5 --tied-embeddings",
    f"--after-batches 12000",
    f"--devices 0 1 --sync-sgd --seed 1111",
    f"--exponential-smoothing",
])

run(f"{MARIAN} {trans_args} --dump-config > {trans_cfg}")
print("\n[info] Starting Transformer training on Dual Tesla T4 GPUs...")
_t_trans = time.time()
run(f"{MARIAN} -c {trans_cfg} 2>&1 | tee {TRANS_DIR}/train.trans.run.log")
trans_duration = (time.time() - _t_trans) / 60
print(f"[info] Transformer training completed in {trans_duration:.2f} minutes.")

# Decode Test Set with Transformer
ckpt_trans = get_best_checkpoint(TRANS_DIR)
hyp_trans = os.path.join(WORKING_DIR, f"test.transformer.{SRC}2{TGT}.hyp.txt")
run(" ".join([
    MARIAN_DECODER,
    f"-m {ckpt_trans}",
    f"-v {vocab_src} {vocab_tgt}",
    f"--devices 0",
    f"--beam-size 6 --normalize 0.6",
    f"< {test_src}",
    f"> {hyp_trans}",
]))

with open(hyp_trans) as f_h, open(test_tgt) as f_r:
    bleu_trans, prec_trans, bp_trans = compute_corpus_bleu([l.strip() for l in f_h], [l.strip() for l in f_r])
print(f"[RESULT] Transformer Test Syllable BLEU: {bleu_trans:.4f} (BP={bp_trans:.4f})")


# ---------------------------------------------------------------------------
# Stage 3: Ensemble Decoding (Seq2Seq + Transformer)
# ---------------------------------------------------------------------------

section("Stage 3: Marian Ensemble Decoding (Seq2Seq + Transformer)")

print(f"[ok] Ensembling S2S Checkpoint        : {ckpt_s2s}")
print(f"[ok] Ensembling Transformer Checkpoint: {ckpt_trans}")

hyp_ensemble = os.path.join(WORKING_DIR, f"test.ensemble.{SRC}2{TGT}.hyp.txt")

_t_ens = time.time()
run(" ".join([
    MARIAN_DECODER,
    f"-m {ckpt_s2s} {ckpt_trans}",
    f"--weights 0.5 0.5",
    f"-v {vocab_src} {vocab_tgt}",
    f"--devices 0",
    f"--beam-size 6 --normalize 0.6",
    f"< {test_src}",
    f"> {hyp_ensemble}",
]))
print(f"[info] Ensemble decoding completed in {time.time() - _t_ens:.2f} seconds.")

with open(hyp_ensemble) as f_h, open(test_tgt) as f_r:
    bleu_ens, prec_ens, bp_ens = compute_corpus_bleu([l.strip() for l in f_h], [l.strip() for l in f_r])
print(f"[RESULT] Ensemble Test Syllable BLEU: {bleu_ens:.4f} (BP={bp_ens:.4f})")


# ---------------------------------------------------------------------------
# Stage 4: Detokenization & Comparative Reporting
# ---------------------------------------------------------------------------

section("Stage 4: Postprocessing Detokenization & Comparative Analysis")

# Detokenize syllable predictions back to raw natural Myanmar text
for name, hyp_p in [("s2s", hyp_s2s), ("transformer", hyp_trans), ("ensemble", hyp_ensemble)]:
    detok_p = os.path.join(WORKING_DIR, f"test.{name}.{SRC}2{TGT}.detok.txt")
    with open(hyp_p) as f_in, open(detok_p, "w", encoding="utf-8") as f_out:
        for line in f_in:
            f_out.write(line.strip().replace(" ", "") + "\n")
    print(f"[ok] Saved detokenized Myanmar hypotheses: {detok_p}")

detok_ensemble = os.path.join(WORKING_DIR, f"test.ensemble.{SRC}2{TGT}.detok.txt")

total_duration = (time.time() - total_start_time) / 60

print("\n" + "=" * 80)
print(f"ASSIGNMENT 6 RESULTS: HIEROGLYPHS -> MYANMAR ({SRC.upper()} -> {TGT.upper()})")
print("=" * 80)
print(f"{'Model Architecture':<32} | {'Syllable BLEU':>14} | {'BP':>8} | {'1-Gram':>8} | {'Train Time':>10}")
print("-" * 80)
print(f"{'Seq2Seq (LSTM + Attention)':<32} | {bleu_s2s:>14.4f} | {bp_s2s:>8.4f} | {prec_s2s[0]*100:>7.2f}% | {s2s_duration:>7.2f} min")
print(f"{'Transformer (Self-Attention)':<32} | {bleu_trans:>14.4f} | {bp_trans:>8.4f} | {prec_trans[0]*100:>7.2f}% | {trans_duration:>7.2f} min")
print(f"{'Ensemble (S2S + Transformer)':<32} | {bleu_ens:>14.4f} | {bp_ens:>8.4f} | {prec_ens[0]*100:>7.2f}% | {'—':>10}")
print("-" * 80)
print(f"Ensemble Gain over S2S         : {bleu_ens - bleu_s2s:+.4f} BLEU")
print(f"Ensemble Gain over Transformer : {bleu_ens - bleu_trans:+.4f} BLEU")
print(f"Total Pipeline Execution Time  : {total_duration:.2f} minutes")
print("=" * 80)

# Save machine-readable evaluation summary
summary_path = os.path.join(WORKING_DIR, "summary_report_hi2my.txt")
with open(summary_path, "w", encoding="utf-8") as f_sum:
    f_sum.write("=== ASSIGNMENT 6 EVALUATION SUMMARY (HI -> MY) ===\n")
    f_sum.write(f"Seq2Seq Syllable BLEU: {bleu_s2s:.4f} (Train: {s2s_duration:.2f}m, BP: {bp_s2s:.4f})\n")
    f_sum.write(f"Transformer Syllable BLEU: {bleu_trans:.4f} (Train: {trans_duration:.2f}m, BP: {bp_trans:.4f})\n")
    f_sum.write(f"Ensemble Syllable BLEU: {bleu_ens:.4f} (BP: {bp_ens:.4f})\n")
    f_sum.write(f"Total Runtime: {total_duration:.2f}m\n")

print("\n--- Detokenized Predictions vs Gold Raw Myanmar (First 15 lines) ---")
if test_raw_my and os.path.exists(test_raw_my):
    run(f"paste {test_src} {detok_ensemble} {test_raw_my} | head -n 15")
else:
    run(f"paste {test_src} {detok_ensemble} | head -n 15")

print(f"\n[ALL DONE] Pipeline completed successfully in {total_duration:.2f} minutes!")

