#POLAR DATASET

#Preview
This dataset contains data collected from multiple sources. Some data were scraped from Wikipedia, while other data were sourced from publicly available datasets on Hugging Face.

##Dataset Credit
@dataset{gojokun00_myanmar_speech_hate_normal,
  author       = {Gojokun00},
  title        = {Myanmar Speech Hate and Normal Dataset},
  year         = {2023},
  publisher    = {Hugging Face},
  howpublished = {\url{https://huggingface.co/datasets/Gojokun00/myanmar_speech_hate_and_normal}}
}

@dataset{simbolo_burmese_hate_speech_small,
  author       = {Simbolo AI},
  title        = {Burmese Hate Speech Small Dataset},
  year         = {2023},
  publisher    = {Hugging Face},
  howpublished = {\url{https://huggingface.co/datasets/simbolo-ai/burmese-hate-speech-small}}
}

@dataset{simbolo_burmese_hatespeech,
  author       = {Simbolo AI},
  title        = {Burmese Hatespeech Dataset},
  year         = {2023},
  publisher    = {Hugging Face},
  howpublished = {\url{https://huggingface.co/datasets/simbolo-ai/burmese-hatespeech}}
}
