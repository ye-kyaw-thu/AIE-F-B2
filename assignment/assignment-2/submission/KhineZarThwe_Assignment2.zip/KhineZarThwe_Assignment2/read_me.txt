1.bbc_burmese.txt   total - 238
2.cni_burmese.txt total - 68
3.religious_burmese.txt total - 152
4.hate_speech.txt  total - 102
5.book.txt - 51

total 
238+68+152+102+51 = 611


