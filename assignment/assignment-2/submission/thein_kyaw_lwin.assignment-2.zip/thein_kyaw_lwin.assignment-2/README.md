# Myanmar POLAR Dataset (600 Sentences)
**Course:** AIEF 2 — Assignment 2  
**Annotator:** Thein Kyaw Lwin (`TheinKyawLwin`)  
**Date:** Aug 22, 2026
---

## 1. Overview & Dataset Breakdown

This dataset contains **600 carefully curated and human-validated sentences** for Myanmar Polarizing Language analysis, spanning **Literature/Books** and **Social Media/Online Comments**.

### Dataset Proportions & Breakdown

| Domains | Range (IDs) | Polarized (`1`) | Neutral (`0`) | Distribution  | % of Grand Total (600) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **📚 Part 1: Literature / Books** | `mya_TheinKyawLwin_1` – `300` | 100 | 200 | **300** | **50.0%** (16.67% Polar / 33.33% Neutral) |
| **🌐 Part 2: Social Media & Comments** | `mya_TheinKyawLwin_301` – `600` | 250 | 50 | **300** | **50.0%** (41.67% Polar / 8.33% Neutral) |
| **🎯 GRAND TOTAL** | `mya_TheinKyawLwin_1` – `600` | **350 (58.33%)** | **250 (41.67%)** | **600** | **100.0%** |

---

## 2. Annotation Workflow


1. **Sourcing & Filtering**:
   - Sentences were extracted from 3 HuggingFace Datasets based on keywords searches and human validation approaches
2. **LLM Pre-Annotation**:
   - Pre-annotated using `gemini-3.5-flash-lite` with few-shots examples guided by official Polar-SemEval benchmark data.
3. **Manual Human Verification**:
   - Every single record was reviewed, validated, and corrected manually using the **Arloo Web Interface** by the annotator (`TheinKyawLwin`).

---

## 3. Acknowledgments & Source Citations

I gratefully acknowledge the creators and maintainers of the following open-source datasets that made this work possible:

```bibtex
@misc{chuuhtetnaing-mm-lib-book-dataset,
  author    = {Chuu Htet Naing},
  title     = {MM-Lib Book Corpus Dataset (437 Books)},
  year      = {2025},
  publisher = {Hugging Face},
  url       = {https://huggingface.co/datasets/chuuhtetnaing/mm-lib-book-dataset},
  note      = {Derived from MM-Lib (Whisper of Words) at https://mm-lib.com/}
}

@misc{burmese-hate-speech-small,
  author    = {{Sa Phyo Thu Htet, Data Science and ML Club, UTYCC}},
  title     = {burmese-hate-speech-small},
  year      = {2024},
  publisher = {Hugging Face},
  url       = {https://huggingface.co/datasets/simbolo-ai/burmese-hate-speech-small},
  urldate   = {2024-03-01}
}

@misc{myanmar-speech-hate-and-normal,
  author    = {Gojokun00},
  title     = {myanmar_speech_hate_and_normal},
  year      = {2024},
  publisher = {Hugging Face},
  url       = {https://huggingface.co/datasets/Gojokun00/myanmar_speech_hate_and_normal}
}
```
