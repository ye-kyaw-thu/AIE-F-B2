# Myanmar POLAR Dataset (600 Sentences)

**Course:** AIE-F Batch 2 — Assignment 2  
**Task:** Multilingual & Multicultural Polarization Detection ([POLAR Benchmark](https://aclanthology.org/2026.findings-acl.1433.pdf))  
**Annotator:** Aung Chan Nyein 


---

## 1. Overview & Dataset Breakdown

This dataset contains **600 carefully curated, word-segmented, and human-validated sentences** (plus 1 official seed example `mya_acn_EG` = 601 total records) for Myanmar Polarizing Language detection. The corpus is balanced between **300 Offline Books/Literature** and **300 Online Social Media** comments and news contents.

### Summary Table

| Category | Range (IDs) | Polarized (`1`) | Neutral (`0`) | Total Rows | Polarization % |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Part 1: Books / Literature (Offline)** | `mya_acn_0003` – `0302` | **240** | **60** | **300** | **80.00%** |
| **Part 2: Social Media (Online)** | `mya_acn_EG`, `0001` – `0002`, `0303` – `0600` | **76** | **225** | **301** | **25.25%** |
| **GRAND TOTAL** | `mya_acn_EG` – `0600` | **316** | **285** | **601** | **52.58%** |

> **Corpus Polarization Rate:** **52.58%** (316 / 601) — strategically positioned within the 50%–65% target window, balancing natural social media discourse (~25%) with heightened literary and editorial conflict excerpts (~80%).

---

## 2. Annotation Distribution Details

### Task 2: Polarization Domains (among 316 polarized sentences)
- **Political:** 124 (39.2%) — State of Myanmar, political commentary, military discourse, governance.
- **Other / Abuse:** 96 (30.4%) — General insult, moral condemnation, vulgarity, interpersonal contempt.
- **Racial / Ethnic:** 90 (28.5%) — Ethnic disputes, racial slurs, xenophobic rhetoric.
- **Religious:** 17 (5.4%) — Sectarian disputes, religious extremist rebukes.
- **Gender / Sexual:** 16 (5.1%) — Gender stereotypes, misogynistic slurs, sexism.

### Task 3: Polarization Manifestations (among 316 polarized sentences)
- **Vilification:** 255 (80.7%) — Character assassination, public shaming, insults.
- **Extreme Language:** 131 (41.5%) — Incitement, death wishes, aggressive hyperbole.
- **Invalidation:** 93 (29.4%) — Dismissing human dignity, silencing, invalidating status.
- **Lack of Empathy:** 53 (16.8%) — Rejoicing over suffering, callous indifference.
- **Stereotype:** 51 (16.1%) — Essentializing groups, sweeping prejudice.
- **Dehumanization:** 48 (15.2%) — Comparing opponents to animals, pests, or trash.

---

## 3. Annotation Standards & Validation

1. **Word Segmentation**:
   - All sentences are segmented with Myanmar Unicode spaces using `pyidaungsu` with syllable fallback for long compound tokens.
2. **Keyword Delimiters**:
   - Keywords across **all 601 rows** use the triple-pipe delimiter (`" ||| "`) for consistent multi-phrase segmentation.
3. **Hierarchical Consistency**:
   - `polarization == 0` $\implies$ all Task 2 and Task 3 labels are strictly `0`.
   - `polarization == 1` $\implies \ge 1$ Task 2 domain and $\ge 1$ Task 3 manifestation are `1`.
4. **Clean Citations**:
   - Offline book citations follow `www.mm-lib.com/book/<id> ||| <Title> (<Author>)` (without `https://` prefixes to avoid URL warnings for offline data).
   - Online social media citations include verified TikTok, Facebook, and YouTube URLs.
5. **Official Verification**:
   - Checked with `validate_annotations.py`: **0 ERRORS**.

---

## 4. References & Data Sources

1. **Classic Myanmar Literature (MM-Lib)**: Whisper of Words digital library (`www.mm-lib.com`).
2. **Journal & Literature Excerpts**: *Bullet News Journal* (`www.mm-lib.com/journal/bullet`)
3. **Public Social Media**: TikTok News Videos, Facebook Public Comments, and YouTube Public Discussions.
4. **POLAR Benchmark Paper**: [POLAR: A Benchmark for Multilingual, Multicultural, and Multi-Event Online Polarization (ACL 2026)](https://aclanthology.org/2026.findings-acl.1433.pdf).
