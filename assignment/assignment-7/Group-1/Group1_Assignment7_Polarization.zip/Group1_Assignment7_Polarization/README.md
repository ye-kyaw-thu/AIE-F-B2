# Group 1 – Assignment 7: myPolar Polarization Detection & Classification

POLAR @ SemEval-2026 subtasks on our Burmese myPolar data (Assignment 2):

| Task | Question | Type |
|---|---|---|
| Task 1 | Is the sentence polarized? | binary |
| Task 2 | Who is the target? (political, racial/ethnic, religious, gender/sexual, other) | multi-label |
| Task 3 | How is it expressed? (stereotype, vilification, dehumanization, extreme language, lack of empathy, invalidation) | multi-label |

## Folder contents

| Path | What it is |
|---|---|
| `Group1_Assignment7_Polarization.pptx` | Presentation slides |
| `myPolar_ML.ipynb` | Traditional ML: SGD, Linear SVM, Decision Tree, Random Forest (CPU) |
| `myPolar_DL.ipynb` | Deep learning from scratch: Bi-LSTM, Transformer (laptop CPU / Apple GPU) |
| `mypolar-pretrained.ipynb` | Fine-tuning XLM-RoBERTa and mBERT (Kaggle T4 GPU) |
| `scripts/merge_mypolar.py` | **Stage 1**: merges the 23 student submissions into one file with full metadata (annotator, source link, platform) |
| `scripts/build_stage2.py` | **Stage 2**: builds the model-ready train / dev / test files from the cleaned Stage-1 file |
| `data/stage1_myPolar_full_clean.csv` | Stage 1 after manual cleaning (12,608 sentences, 24 columns incl. annotator and source) |
| `data/task*_{train,dev,test}.csv` | Stage 2 files used by all notebooks (columns: id, text, text_syllable + labels) |
| `results/` | Scores saved by the notebooks (ML, DL, pre-trained) |

**dev** = development set = validation set (15%), used to choose models, epochs and thresholds. **test** (15%) is used only once for the final score.

## Data pipeline

1. `python3 scripts/merge_mypolar.py --input <folder with the 23 submission zips> --output <folder>` → `stage1_myPolar_full.csv`
2. Manual group cleaning → `stage1_myPolar_full_clean.csv`
3. `python3 scripts/build_stage2.py --input data/stage1_myPolar_full_clean.csv --output .` → `stage2/` (identical to the files in `data/`)

Main cleaning steps: Zawgyi → Unicode (18 sentences); POLAR rule (non-polarized → type & manifestation labels = 0, 1,972 fixes); duplicates removed (1,053); commas, emoji, quotes, brackets and invisible characters removed; 586 unlabelled sentences saved for future labelling (not used in train, dev or test). Split: 70 / 15 / 15, the same for all three tasks (seed 42).

## How to run the notebooks

Run from this folder (they read `data/`):
- `myPolar_ML.ipynb` and `myPolar_DL.ipynb`: Jupyter on a laptop (`pip install torch scikit-learn pandas`).
- `mypolar-pretrained.ipynb`: Kaggle with GPU T4 and Internet on; upload the 9 `data/task*.csv` files as a Kaggle dataset.

## Results (test macro-F1)

| Model | Task 1 | Task 2 | Task 3 |
|---|---|---|---|
| Traditional ML (best: SGD / SVM + bigram TF-IDF) | 0.784 | 0.662 | 0.512 |
| Bi-LSTM | 0.768 | 0.600 | 0.520 |
| Transformer (from scratch) | 0.696 | 0.531 | 0.518 |
| XLM-RoBERTa base | **0.802** | **0.677** | 0.479 |
| mBERT | 0.741 | 0.581 | **0.526** |

Note: XLM-RoBERTa did not learn Task 3 (training loss stayed at about 0.92 and it predicted almost every label).
