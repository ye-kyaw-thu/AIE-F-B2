#!/usr/bin/env python
# coding: utf-8

# # Import libraries
# 

# In[4]:


import os
import re
import pickle
import joblib
import numpy as np
import pandas as pd

from collections import Counter

from sklearn.feature_extraction import DictVectorizer
from sklearn.svm import LinearSVC
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    classification_report,
    confusion_matrix
)


# # Checking files

# In[3]:


train_file = "data/train_v5.conll"
val_file = "data/val_v5.conll"
test_file = "data/test_v5.conll"

print("Train:", os.path.exists(train_file))
print("Validation:", os.path.exists(val_file))
print("Test:", os.path.exists(test_file))


# # Preserving the sentence structure

# In[6]:


def read_myner_file(path):
    sentences = []
    current_sentence = []

    with open(path, "r", encoding="utf-8") as f:

        for line in f:
            line = line.rstrip("\n")

            # Blank line = sentence boundary
            if not line.strip():

                if current_sentence:
                    sentences.append(current_sentence)
                    current_sentence = []

                continue

            parts = line.split("\t")

            if len(parts) != 3:
                raise ValueError(
                    f"Expected 3 columns but got {len(parts)}: {line}"
                )

            word, pos, ner = parts

            current_sentence.append({
                "word": word,
                "pos": pos,
                "ner": ner
            })

    if current_sentence:
        sentences.append(current_sentence)

    return sentences


# # Load train/validation/test

# In[7]:


train_data = read_myner_file(train_file)
val_data = read_myner_file(val_file)
test_data = read_myner_file(test_file)

print("Train sentences:", len(train_data))
print("Validation sentences:", len(val_data))
print("Test sentences:", len(test_data))


# # Inspect the data

# In[8]:


for token in train_data[0]:
    print(
        token["word"],
        token["pos"],
        token["ner"],
        sep="\t"
    )


# # Count NER labels

# In[9]:


ner_counter = Counter()

for sentence in train_data:
    for token in sentence:
        ner_counter[token["ner"]] += 1

print("Number of NER labels:", len(ner_counter))

for label, count in ner_counter.most_common():
    print(f"{label:10} {count}")


# # Two NER Configurations
# # Model A: Without POS
# # Model B: With POS

# # Building Model A features

# In[10]:


def features_without_pos(sentence, i):

    word = sentence[i]["word"]

    features = {}

    # Current word
    features["w=" + word] = 1

    # Prefix and suffix features
    for n in (1, 2, 3):

        if len(word) >= n:
            features[f"p{n}={word[:n]}"] = 1
            features[f"s{n}={word[-n:]}"] = 1

    # Word properties
    features[
        f"has_digit={any(c.isdigit() for c in word)}"
    ] = 1

    features[
        f"len={min(len(word), 10)}"
    ] = 1

    # Previous word
    if i > 0:
        features[
            f"w-1={sentence[i-1]['word']}"
        ] = 1

    # Two words before
    if i > 1:
        features[
            f"w-2={sentence[i-2]['word']}"
        ] = 1

    # Next word
    if i < len(sentence) - 1:
        features[
            f"w+1={sentence[i+1]['word']}"
        ] = 1

    # Two words after
    if i < len(sentence) - 2:
        features[
            f"w+2={sentence[i+2]['word']}"
        ] = 1

    # Surrounding-word combination
    if 0 < i < len(sentence) - 1:

        prev_word = sentence[i-1]["word"]
        next_word = sentence[i+1]["word"]

        features[
            f"w-1_w+1={prev_word}|{next_word}"
        ] = 1

    return features


# # Building Model B features

# In[11]:


def features_with_pos(sentence, i):

    features = features_without_pos(sentence, i)

    word = sentence[i]["word"]
    pos = sentence[i]["pos"]

    # Current POS
    features[f"pos={pos}"] = 1

    # Previous POS
    if i > 0:
        features[
            f"pos-1={sentence[i-1]['pos']}"
        ] = 1

    # Next POS
    if i < len(sentence) - 1:
        features[
            f"pos+1={sentence[i+1]['pos']}"
        ] = 1

    # Word + POS combination
    features[
        f"word_pos={word}|{pos}"
    ] = 1

    return features


# # Converting data into X and y

# In[12]:


def prepare_data(data, feature_function):

    X = []
    y = []

    for sentence in data:

        for i in range(len(sentence)):

            features = feature_function(
                sentence,
                i
            )

            X.append(features)

            y.append(
                sentence[i]["ner"]
            )

    return X, y


# # Preparing Model A data

# In[13]:


X_train_A_dict, y_train_A = prepare_data(
    train_data,
    features_without_pos
)

X_val_A_dict, y_val_A = prepare_data(
    val_data,
    features_without_pos
)

X_test_A_dict, y_test_A = prepare_data(
    test_data,
    features_without_pos
)


# In[19]:


def convert_sparse_indices_to_int32(X):
    X = X.tocsr()
    X.indices = X.indices.astype(np.int32)
    X.indptr = X.indptr.astype(np.int32)
    return X


# # Vectorizing Model A

# In[20]:


vectorizer_A = DictVectorizer()

X_train_A = vectorizer_A.fit_transform(
    X_train_A_dict
)

X_val_A = vectorizer_A.transform(
    X_val_A_dict
)

X_test_A = vectorizer_A.transform(
    X_test_A_dict
)

# Convert sparse matrix indices from int64 to int32
X_train_A = convert_sparse_indices_to_int32(X_train_A)
X_val_A = convert_sparse_indices_to_int32(X_val_A)
X_test_A = convert_sparse_indices_to_int32(X_test_A)

print("Train:", X_train_A.shape)
print("Validation:", X_val_A.shape)
print("Test:", X_test_A.shape)


# In[21]:


print("indices:", X_train_A.indices.dtype)
print("indptr:", X_train_A.indptr.dtype)


# # Training Model A baseline

# In[40]:


model_A = LinearSVC(
    C=1.0,
    max_iter=3000
)

model_A.fit(
    X_train_A,
    y_train_A
);


# # Evaluate Model A

# In[24]:


pred_A = model_A.predict(X_test_A)

print(
    classification_report(
        y_test_A,
        pred_A,
        digits=4,
        zero_division=0
    )
)


# In[25]:


accuracy_A = accuracy_score(
    y_test_A,
    pred_A
)

print("Model A Accuracy:", accuracy_A)


# # Preparing Model B Data

# In[31]:


X_train_B_dict, y_train_B = prepare_data(
    train_data,
    features_with_pos
)

X_val_B_dict, y_val_B = prepare_data(
    val_data,
    features_with_pos
)

X_test_B_dict, y_test_B = prepare_data(
    test_data,
    features_with_pos
)


# # Vectorizing Model B

# In[32]:


vectorizer_B = DictVectorizer()

X_train_B = vectorizer_B.fit_transform(
    X_train_B_dict
)

X_val_B = vectorizer_B.transform(
    X_val_B_dict
)

X_test_B = vectorizer_B.transform(
    X_test_B_dict
)

# Convert sparse matrix indices from int64 to int32
X_train_B = convert_sparse_indices_to_int32(X_train_B)
X_val_B = convert_sparse_indices_to_int32(X_val_B)
X_test_B = convert_sparse_indices_to_int32(X_test_B)

print("Train:", X_train_B.shape)
print("Validation:", X_val_B.shape)
print("Test:", X_test_B.shape)


# ### Checking Sparse Matrix Index Type

# In[33]:


print("indices:", X_train_B.indices.dtype)
print("indptr:", X_train_B.indptr.dtype)


# # Training Model B — Baseline SVM

# In[34]:


model_B = LinearSVC(
    C=1.0,
    max_iter=3000
)

print("Training Model B...")

model_B.fit(
    X_train_B,
    y_train_B
)

print("Model B training finished!")


# # Evaluating Model B — Baseline

# In[35]:


pred_B = model_B.predict(X_test_B)

print(
    classification_report(
        y_test_B,
        pred_B,
        digits=4,
        zero_division=0
    )
)


# # Model B Accuracy

# In[36]:


accuracy_B = accuracy_score(
    y_test_B,
    pred_B
)

print("Model B Accuracy:", accuracy_B)


# # Tune Model A

# In[39]:


results_A = []

C_values = [
    0.01,
    0.05,
    0.1,
    0.5,
    1.0,
    2.0,
    5.0,
    10.0
]

for C in C_values:

    print(f"Training Model A with C={C}...")

    model = LinearSVC(
        C=C,
        max_iter=10000
    )

    model.fit(
        X_train_A,
        y_train_A
    )

    pred = model.predict(
        X_val_A
    )

    accuracy = accuracy_score(
        y_val_A,
        pred
    )

    report = classification_report(
        y_val_A,
        pred,
        output_dict=True,
        zero_division=0
    )

    results_A.append({
        "C": C,
        "Accuracy": accuracy,
        "Macro_F1": report["macro avg"]["f1-score"],
        "Weighted_F1": report["weighted avg"]["f1-score"]
    })

    print(f"Finished C={C}")

results_A_df = pd.DataFrame(results_A)

results_A_df


# # Tune Model B

# In[41]:


results_B = []

for C in C_values:

    print(f"Training Model B with C={C}...")

    model = LinearSVC(
        C=C,
        max_iter=10000
    )

    model.fit(
        X_train_B,
        y_train_B
    )

    pred = model.predict(
        X_val_B
    )

    accuracy = accuracy_score(
        y_val_B,
        pred
    )

    report = classification_report(
        y_val_B,
        pred,
        output_dict=True,
        zero_division=0
    )

    results_B.append({
        "C": C,
        "Accuracy": accuracy,
        "Macro_F1": report["macro avg"]["f1-score"],
        "Weighted_F1": report["weighted avg"]["f1-score"]
    })

    print(f"Finished C={C}")

results_B_df = pd.DataFrame(results_B)

results_B_df


# # Finding the best C for model A

# In[42]:


best_A = results_A_df.loc[
    results_A_df["Macro_F1"].idxmax()
]

best_C_A = best_A["C"]

print("Best Model A C:", best_C_A)
print(best_A)


# # Finding the best c for model B

# In[43]:


best_B = results_B_df.loc[
    results_B_df["Macro_F1"].idxmax()
]

best_C_B = best_B["C"]

print("Best Model B C:", best_C_B)
print(best_B)


# # Train the final Model A

# In[44]:


model_A_final = LinearSVC(
    C=best_C_A,
    max_iter=10000
)

print("Training final Model A...")

model_A_final.fit(
    X_train_A,
    y_train_A
)

print("Final Model A training finished!")


# In[46]:


final_pred_A = model_A_final.predict(
    X_test_A
)


# # Train the final Model B

# In[48]:


model_B_final = LinearSVC(
    C=best_C_B,
    max_iter=10000
)

print("Training final Model B...")

model_B_final.fit(
    X_train_B,
    y_train_B
)

print("Final Model B training finished!")


# In[49]:


pred_B_final = model_B_final.predict(
    X_test_B
)


# # Final evaluation
# # Model A

# In[50]:


print("===== FINAL MODEL A: WITHOUT POS =====")

print(
    classification_report(
        y_test_A,
        final_pred_A,
        digits=4,
        zero_division=0
    )
)


# # Final evaluation
# # Model B

# In[52]:


print("===== FINAL MODEL B: WITH POS =====")

print(
    classification_report(
        y_test_B,
        pred_B_final,
        digits=4,
        zero_division=0
    )
)


# # comparison table

# In[53]:


def get_metrics(y_true, y_pred):

    report = classification_report(
        y_true,
        y_pred,
        output_dict=True,
        zero_division=0
    )

    return {
        "Accuracy": accuracy_score(
            y_true,
            y_pred
        ),

        "Macro Precision": report[
            "macro avg"
        ]["precision"],

        "Macro Recall": report[
            "macro avg"
        ]["recall"],

        "Macro F1": report[
            "macro avg"
        ]["f1-score"],

        "Weighted F1": report[
            "weighted avg"
        ]["f1-score"]
    }


# In[55]:


metrics_A = get_metrics(
    y_test_A,
    final_pred_A
)

metrics_B = get_metrics(
    y_test_B,
    pred_B_final
)


# In[56]:


comparison_df = pd.DataFrame(
    [
        {
            "Model": "SVM without POS",
            "Best C": best_C_A,
            **metrics_A
        },
        {
            "Model": "SVM with POS",
            "Best C": best_C_B,
            **metrics_B
        }
    ]
)

comparison_df


# # Determine which model is better

# In[57]:


if metrics_B["Macro F1"] > metrics_A["Macro F1"]:
    print("The SVM model WITH POS performs better based on Macro-F1.")
elif metrics_A["Macro F1"] > metrics_B["Macro F1"]:
    print("The SVM model WITHOUT POS performs better based on Macro-F1.")
else:
    print("Both models have the same Macro-F1.")


# # Compare the tuning results

# In[58]:


print("MODEL A — WITHOUT POS")
display(results_A_df)

print("\nMODEL B — WITH POS")
display(results_B_df)


# # Plot tuning results
# # Model A

# In[59]:


import matplotlib.pyplot as plt

plt.figure(figsize=(8, 5))

plt.plot(
    results_A_df["C"],
    results_A_df["Macro_F1"],
    marker="o"
)

plt.xscale("log")

plt.xlabel("C")
plt.ylabel("Validation Macro-F1")
plt.title("SVM Without POS: Hyperparameter Tuning")

plt.show()


# # Model B

# In[60]:


plt.figure(figsize=(8, 5))

plt.plot(
    results_B_df["C"],
    results_B_df["Macro_F1"],
    marker="o"
)

plt.xscale("log")

plt.xlabel("C")
plt.ylabel("Validation Macro-F1")
plt.title("SVM With POS: Hyperparameter Tuning")

plt.show()


# # Confusion matrix
# # Model A

# In[61]:


labels = sorted(set(y_test_A))

cm_A = confusion_matrix(
    y_test_A,
    final_pred_A,
    labels=labels
)

cm_A_df = pd.DataFrame(
    cm_A,
    index=labels,
    columns=labels
)

cm_A_df


# # Model B

# In[63]:


labels = sorted(set(y_test_B))

cm_B = confusion_matrix(
    y_test_B,
     pred_B_final,
    labels=labels
)

cm_B_df = pd.DataFrame(
    cm_B,
    index=labels,
    columns=labels
)

cm_B_df

