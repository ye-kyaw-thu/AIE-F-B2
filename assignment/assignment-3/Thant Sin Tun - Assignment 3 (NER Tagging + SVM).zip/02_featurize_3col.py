#!/usr/bin/env python3
"""
Extract word-level + POS features and write LIBSVM-format files for LIBLINEAR.

Input format:
    WORD    POS    NER

Example:
    ပက္ကော်    n      B-LOC
    ရွာမ       n      I-LOC
    ရွာ        n      E-LOC
    သည်       ppm     O

Features:
    WORD + POS + word context + POS context

Target:
    NER
"""

import sys
import pickle


def read_conll(path):
    """Read 3-column CoNLL data: WORD, POS, NER."""
    sents = []
    cur = []

    with open(path, encoding='utf-8') as f:
        for line in f:
            line = line.rstrip('\n')

            # Sentence boundary
            if not line.strip():
                if cur:
                    sents.append(cur)
                    cur = []
            else:
                columns = line.split('\t')

                if len(columns) != 3:
                    raise ValueError(
                        f"Expected 3 columns (WORD, POS, NER), "
                        f"but got {len(columns)}: {line}"
                    )

                word, pos, ner = columns

                cur.append((word, pos, ner))

    if cur:
        sents.append(cur)

    return sents


def extract_features(sent, i):
    """Return features for token at position i."""

    word = sent[i][0]
    pos = sent[i][1]

    feats = []

    # --------------------------------------------------
    # Current word
    # --------------------------------------------------

    feats.append(f'w={word}')

    # Word prefixes and suffixes
    for n in (1, 2, 3):
        if len(word) >= n:
            feats.append(f'p{n}={word[:n]}')
            feats.append(f's{n}={word[-n:]}')

    # Word properties
    feats.append(
        f'has_digit={any(c.isdigit() for c in word)}'
    )

    feats.append(
        f'len={min(len(word), 10)}'
    )

    # --------------------------------------------------
    # Current POS
    # --------------------------------------------------

    feats.append(f'pos={pos}')

    # --------------------------------------------------
    # Previous word
    # --------------------------------------------------

    if i > 0:
        prev_word = sent[i - 1][0]
        prev_pos = sent[i - 1][1]

        feats.append(f'w-1={prev_word}')
        feats.append(f'pos-1={prev_pos}')

    # --------------------------------------------------
    # Two words before
    # --------------------------------------------------

    if i > 1:
        prev2_word = sent[i - 2][0]
        prev2_pos = sent[i - 2][1]

        feats.append(f'w-2={prev2_word}')
        feats.append(f'pos-2={prev2_pos}')

    # --------------------------------------------------
    # Next word
    # --------------------------------------------------

    if i < len(sent) - 1:
        next_word = sent[i + 1][0]
        next_pos = sent[i + 1][1]

        feats.append(f'w+1={next_word}')
        feats.append(f'pos+1={next_pos}')

    # --------------------------------------------------
    # Two words after
    # --------------------------------------------------

    if i < len(sent) - 2:
        next2_word = sent[i + 2][0]
        next2_pos = sent[i + 2][1]

        feats.append(f'w+2={next2_word}')
        feats.append(f'pos+2={next2_pos}')

    # --------------------------------------------------
    # Surrounding word bigram
    # --------------------------------------------------

    if 0 < i < len(sent) - 1:
        feats.append(
            f'w-1_w+1={sent[i-1][0]}|{sent[i+1][0]}'
        )

    # --------------------------------------------------
    # POS bigram
    # --------------------------------------------------

    if 0 < i < len(sent) - 1:
        feats.append(
            f'pos-1_pos+1={sent[i-1][1]}|{sent[i+1][1]}'
        )

    return feats


class Vocab:

    def __init__(self):
        self.feat2id = {}      # feature string → integer
        self.label2id = {}     # NER tag → integer
        self.id2label = []     # integer → NER tag

    def add_feat(self, f):
        if f not in self.feat2id:
            self.feat2id[f] = len(self.feat2id) + 1

    def get_feat(self, f):
        return self.feat2id.get(f, -1)

    def add_label(self, label):
        if label not in self.label2id:
            self.label2id[label] = len(self.id2label) + 1
            self.id2label.append(label)

    def get_label(self, label):
        return self.label2id.get(label, -1)


def main():

    if len(sys.argv) != 5:
        print(
            "Usage: python3 02_featurize.py "
            "<train|test> <input.conll> <output.svm> <vocab.pkl>"
        )
        sys.exit(1)

    mode = sys.argv[1]
    conll_path = sys.argv[2]
    out_path = sys.argv[3]
    vocab_path = sys.argv[4]

    # --------------------------------------------------
    # Read data
    # --------------------------------------------------

    sents = read_conll(conll_path)

    print(
        f'[featurize] Read {len(sents)} sentences '
        f'from {conll_path}'
    )

    # --------------------------------------------------
    # Build vocabulary from training data
    # --------------------------------------------------

    if mode == 'train':

        vocab = Vocab()

        for sent in sents:

            for i in range(len(sent)):

                # Add features
                for f in extract_features(sent, i):
                    vocab.add_feat(f)

                # Add NER label
                ner = sent[i][2]
                vocab.add_label(ner)

        # Save vocabulary
        with open(vocab_path, 'wb') as vf:
            pickle.dump(vocab, vf)

        print(
            f'[featurize] vocab size: '
            f'{len(vocab.feat2id)} features, '
            f'{len(vocab.id2label)} labels'
        )

    # --------------------------------------------------
    # Load vocabulary for test
    # --------------------------------------------------

    else:

        with open(vocab_path, 'rb') as vf:
            vocab = pickle.load(vf)

        print(
            f'[featurize] loaded vocabulary: '
            f'{len(vocab.feat2id)} features, '
            f'{len(vocab.id2label)} labels'
        )

    # --------------------------------------------------
    # Write LIBSVM file
    # --------------------------------------------------

    with open(out_path, 'w', encoding='utf-8') as out:

        for sent in sents:

            for i in range(len(sent)):

                feats = extract_features(sent, i)

                # Convert feature strings → feature IDs
                ids = sorted({
                    vocab.get_feat(f)
                    for f in feats
                    if vocab.get_feat(f) > 0
                })

                # IMPORTANT:
                # NER is column 3
                ner = sent[i][2]

                label = vocab.get_label(ner)

                # Unknown label
                if label < 0:
                    raise ValueError(
                        f"Unknown NER label '{ner}' "
                        f"at sentence token {i}"
                    )

                feat_str = ' '.join(
                    f'{fid}:1'
                    for fid in ids
                )

                # LIBSVM format:
                # label feature_id:value feature_id:value ...

                out.write(
                    f'{label} {feat_str}\n'
                )

    print(
        f'[featurize] {mode}: '
        f'{conll_path} → {out_path}'
    )


if __name__ == '__main__':
    main()
