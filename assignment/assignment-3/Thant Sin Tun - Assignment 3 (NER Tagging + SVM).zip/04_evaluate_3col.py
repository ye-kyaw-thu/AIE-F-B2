#!/usr/bin/env python3
"""
Evaluate LIBLINEAR predictions against gold CoNLL file.

Input CoNLL format:
    WORD    POS    NER

Outputs:
    Overall accuracy
    Per-tag precision / recall / F1
    Macro-F1
"""

import sys
import pickle
from collections import Counter


# Define the Vocab class so pickle can successfully unpickle the object
class Vocab:
    pass


def read_gold_tags(path):
    """Read NER tags from the 3rd column."""
    tags = []

    with open(path, encoding='utf-8') as f:
        for line in f:
            line = line.rstrip('\n')

            # Skip blank lines
            if not line.strip():
                continue

            parts = line.split('\t')

            if len(parts) != 3:
                raise ValueError(
                    f"Expected 3 columns (WORD, POS, NER), "
                    f"but got {len(parts)}: {line}"
                )

            # parts[0] = WORD
            # parts[1] = POS
            # parts[2] = NER
            tags.append(parts[2])

    return tags


def read_pred_ids(path):
    """Read numeric predictions produced by LIBLINEAR."""
    ids = []

    with open(path) as f:
        for line in f:
            line = line.strip()

            if not line:
                continue

            ids.append(int(line))

    return ids


def main():

    if len(sys.argv) != 4:
        print(
            "Usage: python3 04_evaluate.py "
            "<gold.conll> <predictions> <vocab.pkl>"
        )
        sys.exit(1)

    gold_path = sys.argv[1]
    pred_path = sys.argv[2]
    vocab_path = sys.argv[3]

    # --------------------------------------------------
    # Load vocabulary
    # --------------------------------------------------

    with open(vocab_path, 'rb') as f:
        vocab = pickle.load(f)

    id2label = vocab.id2label

    # --------------------------------------------------
    # Read gold and predictions
    # --------------------------------------------------

    gold_tags = read_gold_tags(gold_path)
    pred_ids = read_pred_ids(pred_path)

    # Convert 1-indexed prediction IDs to string labels
    pred_tags = [
        id2label[i - 1]
        if 0 < i <= len(id2label)
        else 'UNK'
        for i in pred_ids
    ]

    # --------------------------------------------------
    # Check lengths
    # --------------------------------------------------

    assert len(gold_tags) == len(pred_tags), \
        f'Length mismatch: gold={len(gold_tags)} pred={len(pred_tags)}'

    # --------------------------------------------------
    # Overall accuracy
    # --------------------------------------------------

    correct = sum(
        g == p
        for g, p in zip(gold_tags, pred_tags)
    )

    total = len(gold_tags)

    print('\n=== Overall Accuracy ===')
    print(
        f'  {correct}/{total} = '
        f'{correct / total * 100:.2f}%\n'
    )

    # --------------------------------------------------
    # Per-tag Precision / Recall / F1
    # --------------------------------------------------

    tp = Counter()
    fp = Counter()
    fn = Counter()

    for g, p in zip(gold_tags, pred_tags):

        if g == p:
            tp[g] += 1

        else:
            fp[p] += 1
            fn[g] += 1

    all_tags = sorted(
        set(gold_tags) | set(pred_tags)
    )

    print(
        f'{"Tag":<10} '
        f'{"Precision":>10} '
        f'{"Recall":>10} '
        f'{"F1":>10} '
        f'{"TP":>6} '
        f'{"FP":>6} '
        f'{"FN":>6}'
    )

    print('-' * 64)

    macro_f1 = 0.0

    for tag in all_tags:

        precision = (
            tp[tag] / (tp[tag] + fp[tag])
            if (tp[tag] + fp[tag]) > 0
            else 0
        )

        recall = (
            tp[tag] / (tp[tag] + fn[tag])
            if (tp[tag] + fn[tag]) > 0
            else 0
        )

        f1 = (
            2 * precision * recall / (precision + recall)
            if (precision + recall) > 0
            else 0
        )

        macro_f1 += f1

        print(
            f'{tag:<10} '
            f'{precision * 100:>9.2f}% '
            f'{recall * 100:>9.2f}% '
            f'{f1 * 100:>9.2f}% '
            f'{tp[tag]:>6} '
            f'{fp[tag]:>6} '
            f'{fn[tag]:>6}'
        )

    print('-' * 64)

    print(
        f'{"Macro-F1":<10} '
        f'{"":>10} '
        f'{"":>10} '
        f'{macro_f1 / len(all_tags) * 100:>9.2f}%'
    )


if __name__ == '__main__':
    main()
