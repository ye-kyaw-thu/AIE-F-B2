#!/usr/bin/env python3

import sys


def preprocess(input_file, output_file):
    with open(input_file, "r", encoding="utf-8") as infile, \
         open(output_file, "w", encoding="utf-8") as outfile:

        for line in infile:
            line = line.strip()

            # Preserve sentence boundaries
            if not line:
                outfile.write("\n")
                continue

            columns = line.split("\t")

            if len(columns) >= 3:
                word = columns[0]
                pos = columns[1]
                ner = columns[2]

                outfile.write(f"{word}\t{pos}\t{ner}\n")

            else:
                print(f"Warning: Skipping invalid line: {line}")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 01_preprocess.py input.txt output.conll")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    preprocess(input_file, output_file)

    print(f"Preprocessed data saved to: {output_file}")
