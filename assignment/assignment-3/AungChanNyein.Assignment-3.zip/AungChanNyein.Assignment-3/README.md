# Assignment-3: SVM NER Tagger for Myanmar (myNER)

Submitted by: Aung Chan Nyein 

Trains and compares SVM-based Named Entity Recognition models on the [myNER](https://github.com/ye-kyaw-thu/myNER) 7-tags corpus:

- **Model 1 (Without POS / 2-column)**: word, NER-tag
- **Model 2 (With POS / 3-column)**: word, POS-tag, NER-tag (POS used as an input feature)
- **Bonus**: Joint POS_NER label model (POS and NER fused into one target label)

## Files

| File | Purpose |
|---|---|
| `Aung_Chan_Nyein.Assignment-3.ipynb` | Main notebook — runs the full pipeline and shows results |
| `01_preprocess.py` | Filters raw CoNLL data into 2-column or 3-column format |
| `02_featurize.py` | Extracts features and vectorizes them (`DictVectorizer`) |
| `03_train.py` | Trains `LinearSVC`, with `--tune` to grid-search `C` / `class_weight` on the validation set |
| `04_evaluate.py` | Scores a model: token-level and entity-level (`seqeval`) metrics |
| `data/` | `train_v5.conll`, `val_v5.conll`, `test_v5.conll` |
| `requirements.txt` | Python dependencies |

## Running

```bash
pip install -r requirements.txt
jupyter nbconvert --to notebook --execute --inplace Aung_Chan_Nyein.Assignment-3.ipynb
```

The notebook shells out to the scripts above, writing intermediate features/models to `work_2col/`, `work_3col/`, and `work_joint/` (not included in this submission — regenerated on run).

## Results (test set)

| Model | Token Accuracy | Entity F1 |
|---|---|---|
| Model 1 (Without POS) | 98.19% | 91.12% |
| Model 2 (With POS, feature) | 98.21% | 91.47% |
| Bonus (Joint POS_NER label) | 98.20% | 91.35% |

Both models were tuned against `val_v5.conll` (not the test set) before the final test-set evaluation shown above. Adding POS as an input feature gives a small but consistent improvement over the 2-column model.
