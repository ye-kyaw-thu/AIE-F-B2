import pickle
import argparse
from sklearn.feature_extraction import DictVectorizer


def read_conll(path):
    sents, cur = [], []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line.strip():
                if cur:
                    sents.append(cur)
                    cur = []
            else:
                cur.append(tuple(line.split("\t")))
    if cur:
        sents.append(cur)
    return sents


def is_numeric(token):
    numeric_chars = set("၁၂၃၄၅၆၇၈၉၀")
    return token.isdigit() or all(c in numeric_chars for c in token)


def add_character_features(features, token):
    for n in (1, 2, 3):
        if len(token) >= n:
            features[f"prefix_{n}"] = token[:n]
            features[f"suffix_{n}"] = token[-n:]
    return features


def add_context_features(features, sentence, i):
    n = len(sentence)
    for offset in (-2, -1, 1, 2):
        j = i + offset
        key = f"word[{offset:+d}]"
        if 0 <= j < n:
            features[key] = sentence[j][0]
        else:
            features[key] = "<START>" if offset < 0 else "<END>"
    prev_word = sentence[i - 1][0] if i > 0 else "<START>"
    next_word = sentence[i + 1][0] if i < n - 1 else "<END>"
    features["bigram[-1,+1]"] = f"{prev_word}|{next_word}"
    return features


def add_pos_features(features, sentence, i):
    n = len(sentence)
    features["pos"] = sentence[i][1]
    features["pos[-1]"] = sentence[i - 1][1] if i > 0 else "<START>"
    features["pos[+1]"] = sentence[i + 1][1] if i < n - 1 else "<END>"
    return features


def feature_extraction(sentence, i, use_pos):
    token = sentence[i][0]
    n = len(sentence)
    features = {
        "word": token,
        "is_first": i == 0,
        "is_last": i == n - 1,
        "has_hyphen": "-" in token,
        "is_numeric": is_numeric(token),
        "length": min(len(token), 10),
    }
    features = add_character_features(features, token)
    features = add_context_features(features, sentence, i)
    if use_pos:
        features = add_pos_features(features, sentence, i)
    return features


def build_dataset(sents, use_pos, joint_labels):
    X, y, lengths = [], [], []
    for sent in sents:
        lengths.append(len(sent))
        for i in range(len(sent)):
            X.append(feature_extraction(sent, i, use_pos))
            ner = sent[i][-1]
            y.append(f"{sent[i][1]}_{ner}" if joint_labels else ner)
    return X, y, lengths


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["train", "test"])
    parser.add_argument("conll_path")
    parser.add_argument("out_path")
    parser.add_argument("vectorizer_path")
    parser.add_argument("--joint", action="store_true")
    args = parser.parse_args()

    sents = read_conll(args.conll_path)
    use_pos = len(sents[0]) > 0 and len(sents[0][0]) == 3
    X, y, lengths = build_dataset(sents, use_pos, args.joint)

    if args.mode == "train":
        vectorizer = DictVectorizer(sparse=True)
        Xv = vectorizer.fit_transform(X)
        with open(args.vectorizer_path, "wb") as f:
            pickle.dump(vectorizer, f)
    else:
        with open(args.vectorizer_path, "rb") as f:
            vectorizer = pickle.load(f)
        Xv = vectorizer.transform(X)

    with open(args.out_path, "wb") as f:
        pickle.dump({"X": Xv, "y": y, "lengths": lengths}, f)

    print(f"[featurize] mode={args.mode} cols={'3' if use_pos else '2'} joint={args.joint} "
          f"{args.conll_path} -> {args.out_path} dims={Xv.shape}")


if __name__ == "__main__":
    main()
