import argparse


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["2col", "3col"], required=True)
    parser.add_argument("input")
    parser.add_argument("output")
    return parser.parse_args()


def preprocess_file(input_path, output_path, mode):
    sentence_count = 0
    token_count = 0

    with open(input_path, encoding="utf-8") as fin, open(output_path, "w", encoding="utf-8") as fout:
        in_sentence = False
        for line in fin:
            line_str = line.rstrip("\r\n")

            if not line_str.strip():
                if in_sentence:
                    fout.write("\n")
                    sentence_count += 1
                    in_sentence = False
                continue

            parts = line_str.split("\t")
            if len(parts) < 3:
                parts = line_str.split()
            word, pos, ner = parts[0], parts[1], parts[2]

            in_sentence = True
            token_count += 1

            if mode == "2col":
                fout.write(f"{word}\t{ner}\n")
            else:
                fout.write(f"{word}\t{pos}\t{ner}\n")

        if in_sentence:
            fout.write("\n")
            sentence_count += 1

    print(f"[preprocess] mode={mode} {input_path} -> {output_path} "
          f"({sentence_count} sentences, {token_count} tokens)")


def main():
    args = parse_args()
    preprocess_file(args.input, args.output, args.mode)


if __name__ == "__main__":
    main()
