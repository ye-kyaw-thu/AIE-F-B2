import pickle
import argparse
import time
from importlib import import_module
from sklearn.svm import LinearSVC


def load_features(path):
    with open(path, "rb") as f:
        d = pickle.load(f)
    return d["X"], d["y"], d["lengths"]


def fit_model(X, y, C, class_weight):
    model = LinearSVC(C=C, class_weight=class_weight, max_iter=3000, dual=False, random_state=42)
    t0 = time.time()
    model.fit(X, y)
    return model, time.time() - t0


def tune(X_train, y_train, X_val, y_val, val_lengths, joint):
    evaluate = import_module("04_evaluate")
    best = None

    for C in (0.1, 1.0, 10.0):
        model, fit_time = fit_model(X_train, y_train, C, None)
        y_pred = list(model.predict(X_val))
        metrics = evaluate.score(y_val, y_pred, val_lengths, joint=joint)
        print(f"C={C:<5} class_weight=None     entity_f1={metrics['entity_f1']:.4f} fit_time={fit_time:.1f}s")
        if best is None or metrics["entity_f1"] > best["entity_f1"]:
            best = {"C": C, "class_weight": None, "entity_f1": metrics["entity_f1"]}

    model, fit_time = fit_model(X_train, y_train, best["C"], "balanced")
    y_pred = list(model.predict(X_val))
    metrics = evaluate.score(y_val, y_pred, val_lengths, joint=joint)
    print(f"C={best['C']:<5} class_weight=balanced entity_f1={metrics['entity_f1']:.4f} fit_time={fit_time:.1f}s")
    if metrics["entity_f1"] > best["entity_f1"]:
        best = {"C": best["C"], "class_weight": "balanced", "entity_f1": metrics["entity_f1"]}

    print(f"best: C={best['C']} class_weight={best['class_weight']} entity_f1={best['entity_f1']:.4f}")
    return best["C"], best["class_weight"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("train_path")
    parser.add_argument("model_out_path")
    parser.add_argument("--val")
    parser.add_argument("--tune", action="store_true")
    parser.add_argument("--joint", action="store_true")
    parser.add_argument("--C", type=float, default=1.0)
    parser.add_argument("--class-weight", default=None)
    args = parser.parse_args()

    X_train, y_train, _ = load_features(args.train_path)

    C, class_weight = args.C, args.class_weight
    if args.tune and args.val:
        X_val, y_val, val_lengths = load_features(args.val)
        C, class_weight = tune(X_train, y_train, X_val, y_val, val_lengths, args.joint)

    model, fit_time = fit_model(X_train, y_train, C, class_weight)
    with open(args.model_out_path, "wb") as f:
        pickle.dump({"model": model, "C": C, "class_weight": class_weight}, f)

    print(f"[train] C={C} class_weight={class_weight} fit_time={fit_time:.1f}s -> {args.model_out_path}")


if __name__ == "__main__":
    main()
