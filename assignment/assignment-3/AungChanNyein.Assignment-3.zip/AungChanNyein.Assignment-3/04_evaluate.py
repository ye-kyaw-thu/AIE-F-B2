import pickle
import argparse
from sklearn.metrics import accuracy_score, f1_score
from seqeval.metrics import (
    precision_score as seq_precision_score,
    recall_score as seq_recall_score,
    f1_score as seq_f1_score,
    classification_report as seq_classification_report,
)
from seqeval.scheme import IOBES


def unflatten(y_flat, lengths):
    out, idx = [], 0
    for length in lengths:
        out.append(list(y_flat[idx:idx + length]))
        idx += length
    return out


def split_joint(label):
    pos, _, ner = label.partition("_")
    return ner


def score(y_true, y_pred, lengths, joint=False):
    if joint:
        y_true = [split_joint(l) for l in y_true]
        y_pred = [split_joint(l) for l in y_pred]

    token_acc = accuracy_score(y_true, y_pred)
    token_f1_w = f1_score(y_true, y_pred, average="weighted", zero_division=0)
    token_f1_m = f1_score(y_true, y_pred, average="macro", zero_division=0)

    y_true_seq = unflatten(y_true, lengths)
    y_pred_seq = unflatten(y_pred, lengths)
    entity_p = seq_precision_score(y_true_seq, y_pred_seq, mode="strict", scheme=IOBES, zero_division=0)
    entity_r = seq_recall_score(y_true_seq, y_pred_seq, mode="strict", scheme=IOBES, zero_division=0)
    entity_f1 = seq_f1_score(y_true_seq, y_pred_seq, mode="strict", scheme=IOBES, zero_division=0)

    return {
        "token_accuracy": token_acc,
        "token_f1_weighted": token_f1_w,
        "token_f1_macro": token_f1_m,
        "entity_precision": entity_p,
        "entity_recall": entity_r,
        "entity_f1": entity_f1,
    }


def evaluate(test_path, model_path, name="NER Model", joint=False):
    with open(test_path, "rb") as f:
        d = pickle.load(f)
    X_test, y_test, lengths = d["X"], d["y"], d["lengths"]

    with open(model_path, "rb") as f:
        model = pickle.load(f)["model"]
    y_pred = list(model.predict(X_test))

    metrics = score(y_test, y_pred, lengths, joint=joint)

    print(f"=== {name} ===")
    print(f"Token Accuracy   : {metrics['token_accuracy']:.4f}")
    print(f"Token Weighted F1: {metrics['token_f1_weighted']:.4f}")
    print(f"Token Macro F1   : {metrics['token_f1_macro']:.4f}")
    print(f"Entity Precision : {metrics['entity_precision']:.4f}")
    print(f"Entity Recall    : {metrics['entity_recall']:.4f}")
    print(f"Entity F1        : {metrics['entity_f1']:.4f}\n")

    y_true_r = [split_joint(l) for l in y_test] if joint else y_test
    y_pred_r = [split_joint(l) for l in y_pred] if joint else y_pred
    print(seq_classification_report(
        unflatten(y_true_r, lengths), unflatten(y_pred_r, lengths),
        mode="strict", scheme=IOBES, zero_division=0,
    ))

    return {"name": name, **metrics}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("test_path")
    parser.add_argument("model_path")
    parser.add_argument("--name", default="NER Model")
    parser.add_argument("--joint", action="store_true")
    args = parser.parse_args()
    evaluate(args.test_path, args.model_path, args.name, args.joint)


if __name__ == "__main__":
    main()
