import sys


def extract_columns(input_file, output_file):
    with open(input_file, "r", encoding="utf-8") as infile, open(
        output_file, "w", encoding="utf-8"
    ) as outfile:
        for line in infile:
            stripped = line.strip()

            # Preserve blank lines (sentence boundaries)
            if not stripped:
                outfile.write("\n")
                continue

            # Split by any whitespace sequence
            parts = stripped.split()

            if len(parts) >= 3:
                col_a = parts[0]
                col_c = parts[2]
                # Separated by 4 spaces
                outfile.write(f"{col_a}\t{col_c}\n")
            else:
                outfile.write(line)


if __name__ == "__main__":
    # Ensure correct number of arguments passed
    if len(sys.argv) != 3:
        print("Usage: python program.py input.conll output.conll")
        sys.exit(1)

    input_path = sys.argv[1]
    output_path = sys.argv[2]

    extract_columns(input_path, output_path)