#!/usr/bin/env python3

import time
import pickle
import argparse

from sklearn.feature_extraction import DictVectorizer
from sklearn.svm import LinearSVC
from sklearn.metrics import classification_report, accuracy_score


def parse_args():

    parser = argparse.ArgumentParser(
        description="SVM based Myanmar NER model"
    )

    parser.add_argument(
        "--c",
        type=float,
        default=1.0,
        help="SVM C parameter"
    )

    parser.add_argument(
        "--eval",
        default="val",
        choices=["val", "test"],
        help="Dataset used for evaluation"
    )

    parser.add_argument(
        "--model",
        default="ner_model.pkl",
        help="Output model filename"
    )

    parser.add_argument(
        "--train",
        default="train_v5.conll",
        help="Training dataset"
    )

    parser.add_argument(
        "--val",
        default="val_v5.conll",
        help="Validation dataset"
    )

    parser.add_argument(
        "--test",
        default="test_v5.conll",
        help="Testing dataset"
    )

    return parser.parse_args()



def load_conll_data(filepath):

    sentences = []

    current_sentence = []

    with open(filepath, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            # sentence boundary
            if not line:
                if current_sentence:
                    sentences.append(current_sentence)
                    current_sentence = []
                continue
            parts = line.split("\t")
            if len(parts) == 3:
                word = parts[0]
                pos = parts[1]
                ner = parts[2]
                current_sentence.append((word, pos, ner))
        # last sentence
        if current_sentence:
            sentences.append(current_sentence)
    return sentences

def extract_features_and_labels(sentences):
    X = []
    y = []

    for sent in sentences:
        for i, (word, pos, ner) in enumerate(sent):
            features = {
                # current word
                "word": word,
                # POS information
                "pos": pos,
                # morphology
                "prefix_1": word[:1],
                "prefix_2": word[:2],

                "suffix_1": word[-1:],
                "suffix_2": word[-2:],
                # sentence position
                "is_first": i == 0,
                "is_last": i == len(sent)-1
            }
            # previous word
            if i > 0:
                features["prev_word"] = sent[i-1][0]
                features["prev_pos"] = sent[i-1][1]
            else:
                features["prev_word"] = "<BOS>"
                features["prev_pos"] = "<BOS>"
            # next word
            if i < len(sent)-1:
                features["next_word"] = sent[i+1][0]
                features["next_pos"] = sent[i+1][1]
            else:
                features["next_word"] = "<EOS>"
                features["next_pos"] = "<EOS>"
            X.append(features)
            y.append(ner)
    return X, y

def main():
    args = parse_args()
    print("="*50)
    print("SVM Myanmar NER Training")
    print("="*50)
    print("C value:", args.c)
    print("Evaluation dataset:", args.eval)

    # -------------------------
    # Load datasets
    # -------------------------
    print("\n[1/4] Loading datasets...")
    train_sents = load_conll_data(args.train)

    val_sents = load_conll_data(args.val)

    test_sents = load_conll_data(args.test)

    if args.eval == "val":
        eval_sents = val_sents
    else:
        eval_sents = test_sents

    print(
        f"Train sentences: {len(train_sents)}"
    )

    print(
        f"Validation sentences: {len(val_sents)}"
    )

    print(
        f"Test sentences: {len(test_sents)}"
    )

    # -------------------------
    # Feature extraction
    # -------------------------
    print("\n[2/4] Extracting features...")
    X_train_dicts, y_train = extract_features_and_labels(
        train_sents
    )
    X_eval_dicts, y_eval = extract_features_and_labels(
        eval_sents
    )

    # -------------------------
    # Vectorization
    # -------------------------
    print("\n[3/4] Vectorizing features...")
    vectorizer = DictVectorizer(
        sparse=True
    )
    X_train = vectorizer.fit_transform(
        X_train_dicts
    )
    X_eval = vectorizer.transform(
        X_eval_dicts
    )

    # scipy compatibility
    for X in (X_train, X_eval):
        X.indices = X.indices.astype("int32")
        X.indptr = X.indptr.astype("int32")

    print(
        "Train feature shape:",
        X_train.shape
    )

    print(
        "Eval feature shape:",
        X_eval.shape
    )

    # -------------------------
    # Train SVM
    # -------------------------
    print("\n[4/4] Training LinearSVC...")

    start = time.time()

    model = LinearSVC(
        C=args.c,
        max_iter=2000,
        random_state=42
    )

    model.fit(
        X_train,
        y_train
    )

    elapsed = time.time() - start

    print(
        f"Training time: {elapsed:.2f}s"
    )

    # -------------------------
    # Save model
    # -------------------------
    with open(args.model, "wb") as f:
        pickle.dump(
            (model, vectorizer),
            f
        )

    print(
        "Saved model:",
        args.model
    )

    # -------------------------
    # Evaluation
    # -------------------------
    print(
        "\nEvaluation on:",
        args.eval
    )

    y_pred = model.predict(
        X_eval
    )

    acc = accuracy_score(
        y_eval,
        y_pred
    )

    print(
        f"\nAccuracy: {acc*100:.2f}%"
    )

    print(
        "\nClassification Report:"
    )

    print(
        classification_report(
            y_eval,
            y_pred,
            zero_division=0
        )
    )

if __name__ == "__main__":
    main()