#!/usr/bin/env python3
"""
04_evaluate.py - Evaluate LIBLINEAR predictions for NER tagging.

Provides 3 complementary evaluation perspectives:
1. Overall Token Accuracy & Detailed BIOES Sub-Tag Breakdown
2. Aggregated Token-Category Summary
3. STRICT CoNLL ENTITY SPAN EVALUATION (Exact Chunk Match) - Research Standard!

Usage:
    python3 04_evaluate.py <gold_conll> <pred_file> <vocab_pkl> [--name <model_name>]
"""

import sys
import pickle
import argparse
from collections import Counter
import __main__

class Vocab:
    """Vocab class definition matching 02_featurize.py for pickle compatibility."""
    def __init__(self):
        self.feat2id  = {}
        self.label2id = {}
        self.id2label = []

# Ensure Vocab is registered in __main__ for unpickling compatibility
if not hasattr(__main__, 'Vocab'):
    setattr(__main__, 'Vocab', Vocab)

def read_gold_sentences(path):
    """Read gold CoNLL file and return list of sentence token tag lists."""
    sents, cur = [], []
    with open(path, encoding='utf-8') as f:
        for line in f:
            line = line.rstrip('\n')
            if not line.strip():
                if cur:
                    sents.append(cur)
                    cur = []
            else:
                parts = line.split('\t')
                cur.append(parts[-1])  # NER tag is always the last column
    if cur:
        sents.append(cur)
    return sents

def read_pred_ids(path):
    ids = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            ids.append(int(line))
    return ids

def get_entity_category(tag):
    """Extract category from BIOES tag (e.g., 'B-LOC' -> 'LOC', 'S-PER' -> 'PER', 'O' -> 'O')."""
    if tag == 'O' or '-' not in tag:
        return tag
    return tag.split('-', 1)[1]

def extract_bioes_spans(sentence_tags):
    """
    Extract entity spans (type, start_idx, end_idx) from BIOES tags for a sentence.
    Returns set of tuples: (entity_type, start_token_idx, end_token_idx)
    """
    spans = set()
    start_idx = None
    cur_type = None

    for i, tag in enumerate(sentence_tags):
        if tag == 'O':
            if start_idx is not None:
                # Close any unclosed boundary span
                spans.add((cur_type, start_idx, i - 1))
                start_idx = None
                cur_type = None
            continue

        if '-' in tag:
            prefix, etype = tag.split('-', 1)
        else:
            prefix, etype = 'S', tag

        if prefix == 'S':
            if start_idx is not None:
                spans.add((cur_type, start_idx, i - 1))
                start_idx = None
                cur_type = None
            spans.add((etype, i, i))

        elif prefix == 'B':
            if start_idx is not None:
                spans.add((cur_type, start_idx, i - 1))
            start_idx = i
            cur_type = etype

        elif prefix == 'I':
            if start_idx is not None and cur_type == etype:
                pass  # Continue span
            else:
                if start_idx is not None:
                    spans.add((cur_type, start_idx, i - 1))
                start_idx = i
                cur_type = etype

        elif prefix == 'E':
            if start_idx is not None and cur_type == etype:
                spans.add((cur_type, start_idx, i))
            else:
                if start_idx is not None:
                    spans.add((cur_type, start_idx, i - 1))
                spans.add((etype, i, i))
            start_idx = None
            cur_type = None

    if start_idx is not None:
        spans.add((cur_type, start_idx, len(sentence_tags) - 1))

    return spans

def evaluate(gold_path, pred_path, vocab_path, model_name="NER Model"):
    with open(vocab_path, 'rb') as f:
        vocab = pickle.load(f)
    id2label = vocab.id2label

    gold_sents = read_gold_sentences(gold_path)
    pred_ids   = read_pred_ids(pred_path)
    
    # Flatten gold tags and reconstruct pred tags sentence by sentence
    gold_flat = [tag for sent in gold_sents for tag in sent]
    pred_flat = [id2label[i-1] if 0 < i <= len(id2label) else 'UNK' for i in pred_ids]

    assert len(gold_flat) == len(pred_flat), \
        f'Length mismatch: gold={len(gold_flat)} pred={len(pred_flat)}'

    # Reconstruct pred sentences
    pred_sents = []
    idx = 0
    for gsent in gold_sents:
        slen = len(gsent)
        pred_sents.append(pred_flat[idx : idx + slen])
        idx += slen

    # Token accuracy
    correct = sum(g == p for g, p in zip(gold_flat, pred_flat))
    total   = len(gold_flat)
    acc     = (correct / total * 100) if total > 0 else 0.0

    print(f"\n==========================================================================")
    print(f"       EVALUATION RESULTS: {model_name}")
    print(f"==========================================================================")
    print(f" Overall Token Accuracy: {correct}/{total} = {acc:.2f}%\n")

    # ---------------------------------------------------------
    # 1. STRICT CoNLL ENTITY SPAN EVALUATION (Exact Chunk Match)
    # ---------------------------------------------------------
    span_tp = Counter()
    span_fp = Counter()
    span_fn = Counter()

    for g_tags, p_tags in zip(gold_sents, pred_sents):
        g_spans = extract_bioes_spans(g_tags)
        p_spans = extract_bioes_spans(p_tags)

        for span in p_spans:
            etype = span[0]
            if span in g_spans:
                span_tp[etype] += 1
            else:
                span_fp[etype] += 1

        for span in g_spans:
            etype = span[0]
            if span not in p_spans:
                span_fn[etype] += 1

    all_entity_types = sorted(set(span_tp.keys()) | set(span_fp.keys()) | set(span_fn.keys()))

    print(f"--- [STRICT CoNLL ENTITY SPAN EVALUATION (Exact Chunk Match)] ---")
    print(f'{"Entity Type":<18} {"Precision":>10} {"Recall":>10} {"F1-Score":>10} '
          f'{"TP":>7} {"FP":>7} {"FN":>7}')
    print('-' * 75)

    span_macro_f1 = 0.0
    total_tp = sum(span_tp.values())
    total_fp = sum(span_fp.values())
    total_fn = sum(span_fn.values())

    span_metrics = {}

    for etype in all_entity_types:
        p = span_tp[etype] / (span_tp[etype] + span_fp[etype]) if (span_tp[etype] + span_fp[etype]) > 0 else 0.0
        r = span_tp[etype] / (span_tp[etype] + span_fn[etype]) if (span_tp[etype] + span_fn[etype]) > 0 else 0.0
        f1 = 2*p*r / (p+r) if (p+r) > 0 else 0.0
        span_macro_f1 += f1
        span_metrics[etype] = {'precision': p, 'recall': r, 'f1': f1, 'tp': span_tp[etype], 'fp': span_fp[etype], 'fn': span_fn[etype]}

        print(f'{etype:<18} {p*100:>9.2f}% {r*100:>9.2f}% {f1*100:>9.2f}% '
              f'{span_tp[etype]:>7} {span_fp[etype]:>7} {span_fn[etype]:>7}')

    span_macro_f1_avg = (span_macro_f1 / len(all_entity_types) * 100) if all_entity_types else 0.0
    overall_micro_p = total_tp / (total_tp + total_fp) if (total_tp + total_fp) > 0 else 0.0
    overall_micro_r = total_tp / (total_tp + total_fn) if (total_tp + total_fn) > 0 else 0.0
    overall_micro_f1 = 2 * overall_micro_p * overall_micro_r / (overall_micro_p + overall_micro_r) if (overall_micro_p + overall_micro_r) > 0 else 0.0

    print('-' * 75)
    print(f'{"Span Micro-F1":<18} {overall_micro_p*100:>9.2f}% {overall_micro_r*100:>9.2f}% {overall_micro_f1*100:>9.2f}%')
    print(f'{"Span Macro-F1":<18} {"":>10} {"":>10} {span_macro_f1_avg:>9.2f}%\n')

    # ---------------------------------------------------------
    # 2. Token-Level Sub-Tag Evaluation (BIOES Tags)
    # ---------------------------------------------------------
    sub_tp = Counter()
    sub_fp = Counter()
    sub_fn = Counter()

    for g, p in zip(gold_flat, pred_flat):
        if g == p:
            sub_tp[g] += 1
        else:
            sub_fp[p] += 1
            sub_fn[g] += 1

    all_tags = sorted(set(gold_flat) | set(pred_flat))
    macro_f1_subtags = 0.0
    for tag in all_tags:
        p = sub_tp[tag] / (sub_tp[tag] + sub_fp[tag]) if (sub_tp[tag] + sub_fp[tag]) > 0 else 0.0
        r = sub_tp[tag] / (sub_tp[tag] + sub_fn[tag]) if (sub_tp[tag] + sub_fn[tag]) > 0 else 0.0
        f1 = 2*p*r / (p+r) if (p+r) > 0 else 0.0
        macro_f1_subtags += f1
    macro_f1_subtags_avg = (macro_f1_subtags / len(all_tags) * 100) if all_tags else 0.0

    return {
        'model_name': model_name,
        'accuracy': acc,
        'token_macro_f1': macro_f1_subtags_avg,
        'span_micro_f1': overall_micro_f1 * 100,
        'span_macro_f1': span_macro_f1_avg,
        'span_metrics': span_metrics,
        'total_tokens': total,
        'correct_tokens': correct
    }

def main():
    parser = argparse.ArgumentParser(description="Evaluate NER predictions against gold labels.")
    parser.add_argument("gold_conll", help="Path to gold CoNLL file")
    parser.add_argument("pred_file", help="Path to LIBLINEAR prediction output file")
    parser.add_argument("vocab_pkl", help="Path to vocabulary pickle file")
    parser.add_argument("--name", default="NER Model", help="Model display name")
    
    args = parser.parse_args()
    evaluate(args.gold_conll, args.pred_file, args.vocab_pkl, args.name)

if __name__ == '__main__':
    main()
