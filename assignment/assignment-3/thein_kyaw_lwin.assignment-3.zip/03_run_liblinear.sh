#!/bin/bash
# ==============================================================================
#  Assignment 3: SVM Named Entity Recognition (NER) Tagger — LIBLINEAR Pipeline
#  Trains and compares two models:
#    1. Model 1 (Without POS / 2-column format)
#    2. Model 2 (With POS / 3-column format)
# ==============================================================================

set -e

# Directory configurations
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_DIR="${DATA_DIR:-$SCRIPT_DIR/data}"
WORK_2COL_DIR="${WORK_2COL_DIR:-$SCRIPT_DIR/work_2col}"
WORK_3COL_DIR="${WORK_3COL_DIR:-$SCRIPT_DIR/work_3col}"

# Locate LIBLINEAR binaries
if [ -x "$SCRIPT_DIR/liblinear/train" ]; then
    LIBLINEAR_HOME="$SCRIPT_DIR/liblinear"
elif [ -x "$SCRIPT_DIR/../liblinear/train" ]; then
    LIBLINEAR_HOME="$SCRIPT_DIR/../liblinear"
else
    LIBLINEAR_HOME="${1:-/workspace/liblinear}"
fi

TRAIN_BIN="$LIBLINEAR_HOME/train"
PRED_BIN="$LIBLINEAR_HOME/predict"

if [ ! -x "$TRAIN_BIN" ] || [ ! -x "$PRED_BIN" ]; then
    echo "[ERROR] LIBLINEAR binaries not found at $LIBLINEAR_HOME."
    echo "Please specify path to LIBLINEAR or compile liblinear (make) first."
    exit 1
fi

mkdir -p "$WORK_2COL_DIR" "$WORK_3COL_DIR"

echo "=========================================================================="
echo "  [MODEL 1/2] NER Tagging WITHOUT POS Information (2-Column Format)"
echo "=========================================================================="

echo ">>> Step 1: Preprocessing 2-column data..."
python3 "$SCRIPT_DIR/01_preprocess.py" --mode 2col "$DATA_DIR/train_v5.conll" "$WORK_2COL_DIR/train.conll"
python3 "$SCRIPT_DIR/01_preprocess.py" --mode 2col "$DATA_DIR/test_v5.conll"  "$WORK_2COL_DIR/test.conll"

echo ">>> Step 2: Extracting 2-column features..."
python3 "$SCRIPT_DIR/02_featurize.py" train "$WORK_2COL_DIR/train.conll" "$WORK_2COL_DIR/train.svm" "$WORK_2COL_DIR/vocab.pkl"
python3 "$SCRIPT_DIR/02_featurize.py" test  "$WORK_2COL_DIR/test.conll"  "$WORK_2COL_DIR/test.svm"  "$WORK_2COL_DIR/vocab.pkl"
python3 "$SCRIPT_DIR/pkl2txt.py" -i "$WORK_2COL_DIR/vocab.pkl" -o "$WORK_2COL_DIR/vocab.txt"

echo ">>> Step 3: Training Model 1 (Without POS)..."
"$TRAIN_BIN" -s 2 -c 1.0 -e 0.001 "$WORK_2COL_DIR/train.svm" "$WORK_2COL_DIR/model.bin"

echo ">>> Step 4: Predicting on test set (Without POS)..."
"$PRED_BIN" "$WORK_2COL_DIR/test.svm" "$WORK_2COL_DIR/model.bin" "$WORK_2COL_DIR/test.pred" > "$WORK_2COL_DIR/predict.log" 2>&1

echo ">>> Step 5: Evaluating Model 1 (Without POS)..."
python3 "$SCRIPT_DIR/04_evaluate.py" "$WORK_2COL_DIR/test.conll" "$WORK_2COL_DIR/test.pred" "$WORK_2COL_DIR/vocab.pkl" --name "Model 1 (Without POS / 2-col)"


echo ""
echo "=========================================================================="
echo "  [MODEL 2/2] NER Tagging WITH POS Information (3-Column Format)"
echo "=========================================================================="

echo ">>> Step 1: Preprocessing 3-column data..."
python3 "$SCRIPT_DIR/01_preprocess.py" --mode 3col "$DATA_DIR/train_v5.conll" "$WORK_3COL_DIR/train.conll"
python3 "$SCRIPT_DIR/01_preprocess.py" --mode 3col "$DATA_DIR/test_v5.conll"  "$WORK_3COL_DIR/test.conll"

echo ">>> Step 2: Extracting 3-column features (Word + POS context)..."
python3 "$SCRIPT_DIR/02_featurize.py" train "$WORK_3COL_DIR/train.conll" "$WORK_3COL_DIR/train.svm" "$WORK_3COL_DIR/vocab.pkl"
python3 "$SCRIPT_DIR/02_featurize.py" test  "$WORK_3COL_DIR/test.conll"  "$WORK_3COL_DIR/test.svm"  "$WORK_3COL_DIR/vocab.pkl"
python3 "$SCRIPT_DIR/pkl2txt.py" -i "$WORK_3COL_DIR/vocab.pkl" -o "$WORK_3COL_DIR/vocab.txt"

echo ">>> Step 3: Training Model 2 (With POS)..."
"$TRAIN_BIN" -s 2 -c 1.0 -e 0.001 "$WORK_3COL_DIR/train.svm" "$WORK_3COL_DIR/model.bin"

echo ">>> Step 4: Predicting on test set (With POS)..."
"$PRED_BIN" "$WORK_3COL_DIR/test.svm" "$WORK_3COL_DIR/model.bin" "$WORK_3COL_DIR/test.pred" > "$WORK_3COL_DIR/predict.log" 2>&1

echo ">>> Step 5: Evaluating Model 2 (With POS)..."
python3 "$SCRIPT_DIR/04_evaluate.py" "$WORK_3COL_DIR/test.conll" "$WORK_3COL_DIR/test.pred" "$WORK_3COL_DIR/vocab.pkl" --name "Model 2 (With POS / 3-col)"

echo ""
echo "=========================================================================="
echo "  Assignment 3 Pipeline Completed Successfully!"
echo "=========================================================================="
