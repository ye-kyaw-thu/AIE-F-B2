#!/usr/bin/env python3
"""
01_preprocess.py - Preprocess CoNLL data for NER tagging (2-column vs 3-column).

Usage:
    python3 01_preprocess.py --mode 2col input.conll output.conll
    python3 01_preprocess.py --mode 3col input.conll output.conll

Modes:
    2col: Extract (word, NER-tag)  -> 2 columns: word \t NER-tag
    3col: Extract (word, POS-tag, NER-tag) -> 3 columns: word \t POS-tag \t NER-tag
"""

import sys
import argparse

def parse_args():
    parser = argparse.ArgumentParser(description="Preprocess CoNLL dataset for NER tagging.")
    parser.add_argument("--mode", choices=["2col", "3col"], required=True,
                        help="Mode: '2col' (word, NER) or '3col' (word, POS, NER)")
    parser.add_argument("input", help="Input CoNLL file path")
    parser.add_argument("output", help="Output CoNLL file path")
    return parser.parse_args()

def preprocess_file(input_path, output_path, mode):
    sentence_count = 0
    token_count = 0
    
    with open(input_path, encoding='utf-8') as fin, \
         open(output_path, 'w', encoding='utf-8') as fout:
        
        in_sentence = False
        
        for line in fin:
            line_str = line.rstrip('\r\n')
            
            if not line_str.strip():
                if in_sentence:
                    fout.write('\n')
                    sentence_count += 1
                    in_sentence = False
                continue
            
            parts = line_str.split('\t')
            if len(parts) >= 3:
                word, pos, ner = parts[0], parts[1], parts[2]
            elif len(parts) == 2:
                word, pos, ner = parts[0], "UNK", parts[1]
            else:
                continue
            
            in_sentence = True
            token_count += 1
            
            if mode == '2col':
                fout.write(f"{word}\t{ner}\n")
            else:
                fout.write(f"{word}\t{pos}\t{ner}\n")
                
        if in_sentence:
            fout.write('\n')
            sentence_count += 1

    print(f"[preprocess] Mode: {mode} | Input: {input_path} -> Output: {output_path} "
          f"({sentence_count} sentences, {token_count} tokens)")

def main():
    args = parse_args()
    preprocess_file(args.input, args.output, args.mode)

if __name__ == '__main__':
    main()
