#!/usr/bin/env python3
"""
02_featurize.py - Extract features and write libsvm-format files for LIBLINEAR.
Supports both 2-column (Without POS) and 3-column (With POS) NER datasets.

Usage:
    python3 02_featurize.py train <conll_path> <svm_out_path> <vocab_out_path>
    python3 02_featurize.py test  <conll_path> <svm_out_path> <vocab_in_path>
"""

import sys
import pickle

def read_conll(path):
    """Read CoNLL file returning list of sentences.
    Each sentence is a list of tuples:
    - 2-column: (word, ner)
    - 3-column: (word, pos, ner)
    """
    sents, cur = [], []
    with open(path, encoding='utf-8') as f:
        for line in f:
            line = line.rstrip('\n')
            if not line.strip():
                if cur:
                    sents.append(cur)
                    cur = []
            else:
                parts = line.split('\t')
                cur.append(tuple(parts))
    if cur:
        sents.append(cur)
    return sents

def extract_features_2col(sent, i):
    """Word features only (Without POS information)."""
    word = sent[i][0]
    feats = []
    
    # Target word identity
    feats.append(f'w={word}')
    
    # Prefix & Suffix features
    for n in (1, 2, 3):
        if len(word) >= n:
            feats.append(f'p{n}={word[:n]}')
            feats.append(f's{n}={word[-n:]}')
            
    # Surface characteristics
    feats.append(f'has_digit={any(c.isdigit() for c in word)}')
    feats.append(f'len={min(len(word), 10)}')
    
    # Context word features
    if i > 0:
        feats.append(f'w-1={sent[i-1][0]}')
    else:
        feats.append('w-1=<BOS>')
        
    if i > 1:
        feats.append(f'w-2={sent[i-2][0]}')
    else:
        feats.append('w-2=<BOS>')
        
    if i < len(sent) - 1:
        feats.append(f'w+1={sent[i+1][0]}')
    else:
        feats.append('w+1=<EOS>')
        
    if i < len(sent) - 2:
        feats.append(f'w+2={sent[i+2][0]}')
    else:
        feats.append('w+2=<EOS>')
        
    # Surrounding word bigram
    if 0 < i < len(sent) - 1:
        feats.append(f'w-1_w+1={sent[i-1][0]}|{sent[i+1][0]}')
        
    return feats

def extract_features_3col(sent, i):
    """Word features + POS features (With POS information)."""
    # Start with base word features
    feats = extract_features_2col(sent, i)
    
    # POS tag features
    word, pos = sent[i][0], sent[i][1]
    feats.append(f'pos={pos}')
    feats.append(f'w_pos={word}|{pos}')
    
    # Context POS features
    pos_m1 = sent[i-1][1] if i > 0 else '<BOS_POS>'
    pos_m2 = sent[i-2][1] if i > 1 else '<BOS_POS>'
    pos_p1 = sent[i+1][1] if i < len(sent) - 1 else '<EOS_POS>'
    pos_p2 = sent[i+2][1] if i < len(sent) - 2 else '<EOS_POS>'
    
    feats.append(f'pos-1={pos_m1}')
    feats.append(f'pos-2={pos_m2}')
    feats.append(f'pos+1={pos_p1}')
    feats.append(f'pos+2={pos_p2}')
    
    # POS N-grams and combinations
    feats.append(f'pos-1_pos={pos_m1}|{pos}')
    feats.append(f'pos_pos+1={pos}|{pos_p1}')
    feats.append(f'pos-1_pos+1={pos_m1}|{pos_p1}')
    
    return feats

class Vocab:
    def __init__(self):
        self.feat2id  = {}     # feature string -> int (1-indexed)
        self.label2id = {}     # tag string -> int (1-indexed)
        self.id2label = []     # int -> tag string (0-indexed list)
        
    def add_feat(self, f):
        if f not in self.feat2id:
            self.feat2id[f] = len(self.feat2id) + 1
            
    def get_feat(self, f):
        return self.feat2id.get(f, -1)
        
    def add_label(self, l):
        if l not in self.label2id:
            self.label2id[l] = len(self.id2label) + 1
            self.id2label.append(l)
            
    def get_label(self, l):
        return self.label2id.get(l, -1)

def main():
    mode        = sys.argv[1]   # 'train' or 'test'
    conll_path  = sys.argv[2]
    out_path    = sys.argv[3]
    vocab_path  = sys.argv[4]

    sents = read_conll(conll_path)
    if not sents:
        print(f"[ERROR] No sentences found in {conll_path}")
        sys.exit(1)
        
    is_3col = (len(sents[0][0]) == 3)
    feature_extractor = extract_features_3col if is_3col else extract_features_2col

    if mode == 'train':
        vocab = Vocab()
        for sent in sents:
            for i in range(len(sent)):
                for f in feature_extractor(sent, i):
                    vocab.add_feat(f)
                target_ner = sent[i][-1]  # NER tag is always the last column
                vocab.add_label(target_ner)
        with open(vocab_path, 'wb') as vf:
            pickle.dump(vocab, vf)
        print(f'[featurize] Mode: {mode} | Columns: {"3 (With POS)" if is_3col else "2 (Without POS)"} | '
              f'Vocab size: {len(vocab.feat2id)} feats, {len(vocab.id2label)} labels')
    else:
        with open(vocab_path, 'rb') as vf:
            vocab = pickle.load(vf)

    with open(out_path, 'w', encoding='utf-8') as out:
        for sent in sents:
            for i in range(len(sent)):
                feats = feature_extractor(sent, i)
                ids = sorted({vocab.get_feat(f) for f in feats if vocab.get_feat(f) > 0})
                
                target_ner = sent[i][-1]
                label = vocab.get_label(target_ner)
                if label == -1:
                    label = 1  # Fallback for unseen label in test set
                feat_str = ' '.join(f'{fid}:1' for fid in ids)
                out.write(f'{label} {feat_str}\n')
                
    print(f'[featurize] {mode}: {conll_path} -> {out_path}')

if __name__ == '__main__':
    main()
