#!/usr/bin/env python3
"""
Validate/clean myNER CoNLL format (already one token per line, word \t POS_tag \t NER_tag). 
"""

import sys

def parse_line(line):
    """myNER line: word \t pos \t ner. Return (word, pos, ner) or None
    if the line is malformed (wrong number of columns)."""
    parts = line.rstrip('\n').split('\t')
    if len(parts) != 3:
        return None
    word, pos, ner = parts
    if not (word and pos and ner):
        return None
    return (word, pos, ner)

def main():
    inp, outp = sys.argv[1], sys.argv[2]
    n_tokens, n_dropped = 0, 0
    with open(inp, encoding='utf-8') as f, \
         open(outp, 'w', encoding='utf-8') as out:
        for line in f:
            if not line.strip():
                out.write('\n')
                continue
            tok = parse_line(line)
            if tok is None:
                n_dropped += 1
                continue
            word, pos, ner = tok
            out.write(f'{word}\t{pos}\t{ner}\n')
            n_tokens += 1
    print(f'[preprocess] {inp} → {outp}')
    print(f'[preprocess] {n_tokens} tokens written'
          + (f', {n_dropped} malformed lines dropped' if n_dropped else ''))

if __name__ == '__main__':
    main()
